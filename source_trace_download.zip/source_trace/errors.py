# 接口异常模块
class ApiError(Exception):
    def __init__(self, message, status=400, code="invalid_input"):
        super().__init__(message)
        self.status = status
        self.code = code
class NotFoundError(ApiError):
    def __init__(self, message):
        super().__init__(message, 404, "not_found")
class ConflictError(ApiError):
    def __init__(self, message):
        super().__init__(message, 409, "conflict")
