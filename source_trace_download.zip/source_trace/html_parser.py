# HTML字段解析模块
from html.parser import HTMLParser
from .errors import ApiError
from .validation import hash_json
VOID_TAGS = frozenset(("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"))
IGNORED_TAGS = frozenset(("script", "style", "template"))
class SnapshotParser(HTMLParser):
    def __init__(self, target_ids):
        super().__init__(convert_charrefs=True)
        self.target_ids = set(target_ids)
        self.stack = []
        self.tokens = []
        self.matches = {}
        self.ignored = []
    def handle_starttag(self, tag, attrs):
        if self.ignored:
            if tag in IGNORED_TAGS:
                self.ignored.append(tag)
            return
        if tag in IGNORED_TAGS:
            self.ignored.append(tag)
            return
        if len(self.stack) >= 128:
            raise ApiError("HTML嵌套深度超过128")
        attributes = dict(attrs)
        element_id = attributes.get("id")
        node = {"tag": tag, "element_id": element_id, "text": [], "children": [], "path": [parent["tag"] for parent in self.stack] + [tag]}
        if self.stack:
            self.stack[-1]["children"].append(tag)
        node["parent"] = self.stack[-1] if self.stack else None
        if element_id in self.target_ids:
            self.matches.setdefault(element_id, []).append(node)
        self.tokens.append(["start", tag])
        if tag not in VOID_TAGS:
            self.stack.append(node)
    def handle_endtag(self, tag):
        if self.ignored:
            if tag == self.ignored[-1]:
                self.ignored.pop()
            return
        if tag in VOID_TAGS:
            return
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index]["tag"] == tag:
                self.tokens.append(["end", tag])
                del self.stack[index:]
                break
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID_TAGS:
            self.handle_endtag(tag)
    def handle_data(self, data):
        if self.ignored:
            return
        for node in self.stack:
            if node["element_id"] in self.target_ids:
                node["text"].append(data)
    def extract(self, element_id):
        matches = self.matches.get(element_id, [])
        if len(matches) != 1:
            raise ApiError("HTML节点缺失或ID重复: " + element_id)
        node = matches[0]
        siblings = node["parent"]["children"] if node["parent"] else []
        signature = hash_json([node["path"], siblings])
        return "".join(node["text"]).strip(), signature
def parse_snapshot(html, target_ids):
    parser = SnapshotParser(target_ids)
    parser.feed(html)
    parser.close()
    return parser
