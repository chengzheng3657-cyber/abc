# 采集处理服务模块
import hashlib
import json
import uuid
from collections import deque
from dataclasses import asdict
from datetime import datetime, timezone
from .analysis import AnalysisSettings, compare_field, explain_changes, summarize_series
from .errors import ApiError, ConflictError, NotFoundError
from .html_parser import parse_snapshot
from .matching import find_matches
from .rules import evaluate_rules, validate_rules
from .validation import MAX_BODY_BYTES, MAX_FIELDS, hash_json, parse_number, require_date, require_id, require_list, require_object, require_text
class CollectionService:
    def __init__(self, database, settings=None):
        self.database = database
        self.settings = settings or AnalysisSettings()
    def save_source(self, data):
        require_object(data, "来源")
        source_id = require_id(data, "id")
        if source_id.startswith("EVT-"):
            raise ApiError("来源编号不得使用EVT-保留前缀")
        public = data.get("public", True)
        if not isinstance(public, bool):
            raise ApiError("public必须为布尔值")
        source = {
            "id": source_id,
            "name": require_text(data, "name"),
            "region": require_text(data, "region"),
            "type": require_text({"type": data.get("type", "exchange")}, "type"),
            "public": public,
            "rules": validate_rules(data.get("rules", [])),
        }
        source["rule_version"] = hash_json(source["rules"])
        with self.database.transaction():
            try:
                previous = self.database.get_source(source_id)
            except NotFoundError:
                previous = None
            if previous and previous["region"] != source["region"]:
                row = self.database.connection.execute("SELECT 1 FROM events WHERE source=? LIMIT 1", (source_id,)).fetchone()
                if row:
                    raise ConflictError("已有采集记录的来源不得修改区域，请使用新来源编号")
            self.database.save_source(source)
        return source
    def collect(self, data):
        require_object(data, "采集请求")
        source_id = require_id(data, "source_id")
        page_id = require_text(data, "page_id", 200)
        request_id = require_text(data, "request_id", 100)
        request_hash = hash_json(data)
        with self.database.transaction():
            existing = self.database.find_request(source_id, page_id, request_id)
            if existing:
                if existing[0] != request_hash:
                    raise ConflictError("相同request_id不得提交不同内容")
                return existing[1]
            source = self.database.get_source(source_id)
            html = data.get("html")
            if not isinstance(html, str) or not html.strip() or len(html.encode("utf-8")) > MAX_BODY_BYTES:
                raise ApiError("html必须为非空文本且不得超过2MB")
            definitions = require_list(data, "fields", MAX_FIELDS, allow_empty=False)
            definitions = [require_object(item, "字段配置") for item in definitions]
            element_ids = [require_text(item, "element_id", 200) for item in definitions]
            if len(set(element_ids)) != len(element_ids):
                raise ApiError("单次提交不得将同一HTML节点映射为多个字段")
            page = parse_snapshot(html, element_ids)
            previous = self.database.latest_event(source_id, page_id)
            history = self.database.field_history(source_id, page_id)
            event_id = "EVT-" + uuid.uuid4().hex
            fields, used_keys = [], set()
            for definition, element_id in zip(definitions, element_ids):
                key = require_id(definition, "key")
                if key in used_keys:
                    raise ApiError("同一采集请求的字段key不得重复")
                used_keys.add(key)
                field = {
                    "id": event_id + ":" + key,
                    "key": key,
                    "stable_id": hash_json([source_id, page_id, key]),
                    "name": require_text(definition, "name"),
                    "context": require_text(definition, "context"),
                    "unit": require_text(definition, "unit", 40),
                    "metric": require_text(definition, "metric", 100),
                    "period": require_text({"period": definition.get("period", "day")}, "period", 40),
                    "date": require_date(definition, "date"),
                    "element_id": element_id,
                }
                records = history.get(field["stable_id"], [])
                if records and any(records[-1][attribute] != field[attribute] for attribute in ("context", "unit", "metric", "period")):
                    raise ConflictError("字段定义已变化，请使用新的key保留原有历史")
                text, structure_hash = page.extract(element_id)
                field.update(raw_value=text, value=parse_number(text), structure_hash=structure_hash)
                series = {record["date"]: record["value"] for record in records}
                series[field["date"]] = field["value"]
                field["window_start"], field["window_end"] = min(series), max(series)
                field["temporal"] = summarize_series(series, self.settings)
                fields.append(field)
            # 完成整批校验后，在同一事务内写入记录和关系
            checks = evaluate_rules(fields, source["rules"])
            prior_events = {}
            for field in fields:
                records = history.get(field["stable_id"], [])
                prior = records[-1] if records else None
                comparable = True
                parser_comparable, settings_comparable = True, True
                if prior:
                    prior_id = prior["id"].split(":", 1)[0]
                    if prior_id not in prior_events:
                        prior_events[prior_id] = self.database.get_event(prior_id)
                    prior_event = prior_events[prior_id]
                    comparable = prior_event["rule_version"] == source["rule_version"]
                    parser_comparable = prior_event.get("schema_version") == 2
                    settings_comparable = prior_event.get("analysis_settings") == asdict(self.settings)
                field["drift"] = compare_field(field, prior, comparable, self.settings, parser_comparable, settings_comparable)
            explain_changes(fields, source["rules"])
            event = {
                "schema_version": 2,
                "id": event_id,
                "source_id": source_id,
                "page_id": page_id,
                "source": source,
                "region": source["region"],
                "received_at": datetime.now(timezone.utc).isoformat(),
                "html": html,
                "content_hash": hashlib.sha256(html.encode("utf-8")).hexdigest(),
                "structure_hash": hash_json(page.tokens),
                "rule_version": source["rule_version"],
                "rules": source["rules"],
                "analysis_settings": asdict(self.settings),
                "checks": checks,
                "fields": fields,
                "previous_id": previous["id"] if previous else None,
                "previous_chain": previous["chain_hash"] if previous else "0" * 64,
            }
            event["record_hash"] = hash_json(event)
            event["chain_hash"] = hash_json([event["previous_chain"], event["record_hash"]])
            self.database.save_event(event, request_id, request_hash)
            self.database.add_link(source_id, event_id, "collection")
            if previous:
                relation = "page_update" if previous["structure_hash"] != event["structure_hash"] else "next_collection"
                self.database.add_link(previous["id"], event_id, relation)
            for field in fields:
                self.database.add_link(event_id, field["id"], "parsed_from")
                records = history.get(field["stable_id"], [])
                if records:
                    kind = "validation_change" if field["drift"]["constraint_changed"] else "next_observation"
                    self.database.add_link(records[-1]["id"], field["id"], kind, field["drift"])
            return event
    def get_event(self, event_id):
        with self.database.transaction(write=False):
            return self.database.get_event(event_id)
    def associate(self):
        with self.database.transaction():
            return find_matches(self.database, self.settings)
    def trace(self, entity):
        with self.database.transaction(write=False):
            selected, pending, links = {entity}, deque([entity]), {}
            while pending:
                target = pending.popleft()
                for link in self.database.adjacent_links(target):
                    links[link["id"]] = link
                    neighbor = link["upstream"] if link["downstream"] == target else link["downstream"]
                    if neighbor not in selected:
                        if len(selected) >= 2000:
                            raise ApiError("追溯节点超过2000，请缩小查询范围", 413, "trace_limit")
                        selected.add(neighbor)
                        pending.append(neighbor)
            if not links:
                source = self.database.get_source(entity)
                return {"entity": entity, "nodes": [entity], "links": [], "events": [], "source": source}
            events = []
            for node in sorted(selected):
                if node.startswith("EVT-") and ":" not in node:
                    event = self.database.get_event(node)
                    events.append({key: value for key, value in event.items() if key != "html"})
            return {"entity": entity, "nodes": sorted(selected), "links": list(links.values()), "events": events}
    def verify(self):
        with self.database.transaction(write=False):
            chains, failures, count = {}, [], 0
            for event_id, source_id, page_id, payload in self.database.iter_event_records():
                count += 1
                try:
                    event = json.loads(payload)
                    body = {key: value for key, value in event.items() if key not in ("record_hash", "chain_hash")}
                    key = (source_id, page_id)
                    expected_chain, expected_id = chains.get(key, ("0" * 64, None))
                    content_hash = hashlib.sha256(event["html"].encode("utf-8")).hexdigest()
                    valid = (event["id"], event["source_id"], event["page_id"]) == (event_id, source_id, page_id)
                    valid = valid and hash_json(body) == event["record_hash"] and content_hash == event["content_hash"]
                    valid = valid and hash_json([event["previous_chain"], event["record_hash"]]) == event["chain_hash"]
                    valid = valid and event["previous_chain"] == expected_chain and event["previous_id"] == expected_id
                    rows = self.database.connection.execute("SELECT id,payload FROM field_records WHERE event_id=?", (event_id,)).fetchall()
                    indexed_fields = {field_id: json.loads(raw) for field_id, raw in rows}
                    expected_fields = {field["id"]: field for field in event["fields"]}
                    valid = valid and indexed_fields == expected_fields
                    chains[key] = (event["chain_hash"], event["id"])
                except (KeyError, ValueError, TypeError, AttributeError):
                    valid = False
                if not valid:
                    failures.append(event_id)
            return {"valid": not failures, "checked_events": count, "failed_events": failures}
