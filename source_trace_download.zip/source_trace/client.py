# HTTP客户端模块
import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen
class ApiClient:
    def __init__(self, base_url, token=None):
        self.base_url = base_url.rstrip("/")
        self.token = token
    def request(self, path, payload=None, query=None):
        url = self.base_url + path
        if query:
            url += "?" + urlencode(query)
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8") if payload is not None else None
        request = Request(url, data=body, headers=headers)
        with urlopen(request, timeout=20) as response:
            return json.load(response)["data"]
