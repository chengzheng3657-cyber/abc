# 接口集成测试模块
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from source_trace.analysis import AnalysisSettings
from source_trace.client import ApiClient
from source_trace.html_parser import parse_snapshot
from source_trace.http_api import ApiServer
from source_trace.sample_data import make_collection, make_source
from source_trace.service import CollectionService
from source_trace.storage import Database
from source_trace.validation import encode_json
class ApiTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = str(Path(self.directory.name) / "test.sqlite3")
        self.database = Database(self.path)
        self.service = CollectionService(self.database)
        self.server = ApiServer(("127.0.0.1", 0), self.service, ["http://localhost:3000"])
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = "http://127.0.0.1:" + str(self.server.server_port)
        self.client = ApiClient(self.base_url)
        self.client.request("/api/sources", make_source("test"))
    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.database.close()
        self.directory.cleanup()
    def expect_status(self, status, path, data=None):
        with self.assertRaises(HTTPError) as raised:
            self.client.request(path, data)
        error = raised.exception
        self.assertEqual(error.code, status, error.read().decode())
        error.close()
    def test_idempotency_conflict_and_rollback(self):
        payload = make_collection("test", 0)
        event = self.client.request("/api/collect", payload)
        self.assertEqual(event["id"], self.client.request("/api/collect", payload)["id"])
        payload["html"] += " "
        self.expect_status(409, "/api/collect", payload)
        invalid = make_collection("test", 1)
        invalid["fields"][1]["date"] = "2026-02-30"
        self.expect_status(400, "/api/collect", invalid)
        self.assertEqual(self.client.request("/api/verify")["checked_events"], 1)
    def test_parallel_requests_are_idempotent(self):
        payload = make_collection("test", 0)
        with ThreadPoolExecutor(max_workers=8) as workers:
            events = list(workers.map(lambda _: self.client.request("/api/collect", payload), range(12)))
        self.assertEqual(len({event["id"] for event in events}), 1)
        self.assertEqual(self.client.request("/api/verify")["checked_events"], 1)
    def test_independent_connections_preserve_chain(self):
        other = Database(self.path)
        try:
            other_service = CollectionService(other)
            with ThreadPoolExecutor(max_workers=2) as workers:
                jobs = [workers.submit(service.collect, make_collection("test", offset)) for service, offset in ((self.service, 0), (other_service, 1))]
                self.assertEqual(len({job.result()["id"] for job in jobs}), 2)
            self.assertTrue(other_service.verify()["valid"])
        finally:
            other.close()
    def test_reopen_and_content_tampering(self):
        event = self.client.request("/api/collect", make_collection("test", 0))
        other = Database(self.path)
        try:
            self.assertEqual(CollectionService(other).verify()["checked_events"], 1)
            with other.transaction():
                self.assertEqual(other.get_event(event["id"])["fields"][0]["value"], 100)
        finally:
            other.close()
        with self.database.transaction():
            event["html"] += "changed"
            self.database.connection.execute("UPDATE events SET payload=? WHERE id=?", (encode_json(event), event["id"]))
        result = self.client.request("/api/verify")
        self.assertFalse(result["valid"])
        self.assertEqual(result["failed_events"], [event["id"]])
    def test_missing_fields_and_small_sample(self):
        payload = make_collection("test", 0)
        payload["fields"] = payload["fields"][:1]
        event = self.client.request("/api/collect", payload)
        self.assertEqual(event["checks"][0]["status"], "unknown")
        self.assertEqual(event["fields"][0]["drift"]["temporal_state"], "不可判定")
        self.assertEqual(self.client.request("/api/associate", {})["associations"], [])
    def test_rule_inputs_need_consistent_dates_and_units(self):
        for offset, attribute, value in ((0, "date", "2026-10-31"), (1, "unit", "kWh")):
            payload = make_collection("test", offset)
            payload["fields"][1][attribute] = value
            if offset:
                payload["fields"][1]["key"] = "ahead-other"
                source = make_source("test")
                source["rules"][0]["fields"][1] = "ahead-other"
                self.client.request("/api/sources", source)
            result = self.client.request("/api/collect", payload)
            self.assertEqual(result["checks"][0]["status"], "unknown")
    def test_rule_version_and_field_identity(self):
        self.client.request("/api/collect", make_collection("test", 0))
        source = make_source("test")
        source["rules"] = []
        self.client.request("/api/sources", source)
        result = self.client.request("/api/collect", make_collection("test", 1))
        self.assertEqual(result["fields"][0]["drift"]["type"], "规则版本变化，待复核")
        payload = make_collection("test", 2)
        payload["fields"][0]["unit"] = "kWh"
        self.expect_status(409, "/api/collect", payload)
        source["region"] = "其他省"
        self.expect_status(409, "/api/sources", source)
    def test_field_reappears_after_missing_batch(self):
        original = self.client.request("/api/collect", make_collection("test", 0))
        payload = make_collection("test", 1)
        payload["fields"] = payload["fields"][1:]
        self.client.request("/api/collect", payload)
        current = self.client.request("/api/collect", make_collection("test", 2))
        field = current["fields"][0]
        self.assertNotEqual(field["drift"]["type"], "新增字段")
        trace = self.client.request("/api/trace", query={"entity": field["id"]})
        self.assertIn(original["fields"][0]["id"], trace["nodes"])
    def test_duplicate_id_and_invalid_number_are_rejected(self):
        for suffix in ('<div id="total">2</div>', ""):
            payload = make_collection("test", 0)
            payload["html"] += suffix
            if not suffix:
                payload["html"] = payload["html"].replace(">100<", ">1,00<")
            self.expect_status(400, "/api/collect", payload)
        self.assertEqual(self.client.request("/api/verify")["checked_events"], 0)
    def test_strict_source_validation(self):
        for key, value in (("id", None), ("public", "false"), ("rules", {})):
            source = make_source("another")
            source[key] = value
            self.expect_status(400, "/api/sources", source)
    def test_unknown_records_and_wrong_method(self):
        self.expect_status(404, "/api/event?id=missing")
        self.expect_status(404, "/api/trace?entity=missing")
        self.expect_status(405, "/api/collect")
        self.expect_status(404, "/api/not-found", {})
        self.expect_status(400, "/api/event?id=a&id=b")
    def test_json_errors_and_media_type(self):
        bodies = [b'{"id":"a","id":"b"}', b'{"id":NaN}', b'[]', b'\xff', b'{"id":1e999}', b'{"id":"\\ud800"}']
        for body in bodies:
            request = Request(self.base_url + "/api/sources", data=body, headers={"Content-Type": "application/json"})
            with self.assertRaises(HTTPError) as raised:
                urlopen(request, timeout=5)
            self.assertEqual(raised.exception.code, 400)
            raised.exception.close()
        request = Request(self.base_url + "/api/sources", data=b"{}", headers={"Content-Type": "text/plain"})
        with self.assertRaises(HTTPError) as raised:
            urlopen(request, timeout=5)
        self.assertEqual(raised.exception.code, 415)
        raised.exception.close()
    def test_cors_and_access_token(self):
        request = Request(self.base_url + "/api/collect", method="OPTIONS", headers={"Origin": "http://localhost:3000", "Access-Control-Request-Method": "POST"})
        with urlopen(request, timeout=5) as response:
            self.assertEqual(response.headers["Access-Control-Allow-Origin"], "http://localhost:3000")
        request = Request(self.base_url + "/health", headers={"Origin": "https://untrusted.example"})
        with self.assertRaises(HTTPError) as raised:
            urlopen(request, timeout=5)
        self.assertEqual(raised.exception.code, 403)
        raised.exception.close()
        self.server.token = "test-only-token"
        self.expect_status(401, "/health")
        authenticated = ApiClient(self.base_url, "test-only-token")
        self.assertEqual(authenticated.request("/health")["status"], "ok")
    def test_duplicate_length_is_rejected(self):
        connection = HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            connection.putrequest("POST", "/api/sources")
            connection.putheader("Content-Length", "2")
            connection.putheader("Content-Length", "3")
            connection.putheader("Content-Type", "application/json")
            connection.endheaders(b"{}")
            response = connection.getresponse()
            self.assertEqual(response.status, 400)
            response.read()
        finally:
            connection.close()
    def test_framing_limits_and_head_response(self):
        cases = [({"Content-Length": "2097153"}, 413), ({"Transfer-Encoding": "chunked"}, 400), ({"Content-Length": "9" * 13}, 400), ({}, 411)]
        for headers, expected in cases:
            connection = HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
            try:
                connection.putrequest("POST", "/api/sources")
                connection.putheader("Content-Type", "application/json")
                for name, value in headers.items():
                    connection.putheader(name, value)
                connection.endheaders()
                response = connection.getresponse()
                self.assertEqual(response.status, expected)
                response.read()
            finally:
                connection.close()
        connection = HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        try:
            connection.request("HEAD", "/health")
            response = connection.getresponse()
            self.assertEqual(response.status, 405)
            self.assertEqual(response.read(), b"")
        finally:
            connection.close()
    def test_content_updates_keep_structure(self):
        original = self.client.request("/api/collect", make_collection("test", 0))
        updated = self.client.request("/api/collect", make_collection("test", 1))
        self.assertEqual(original["structure_hash"], updated["structure_hash"])
        self.assertNotEqual(original["content_hash"], updated["content_hash"])
    def test_analysis_settings_change_is_not_business_change(self):
        self.client.request("/api/collect", make_collection("test", 0))
        self.service.settings = AnalysisSettings(change_multiplier=2)
        updated = self.client.request("/api/collect", make_collection("test", 1))
        self.assertEqual(updated["fields"][0]["drift"]["type"], "分析参数变化，待复核")
    def test_field_index_tampering_is_detected(self):
        event = self.client.request("/api/collect", make_collection("test", 0))
        with self.database.transaction():
            self.database.connection.execute("UPDATE field_records SET payload=? WHERE id=?", ("{}", event["fields"][0]["id"]))
        self.assertFalse(self.client.request("/api/verify")["valid"])
    def test_latest_batch_does_not_match_removed_fields(self):
        self.client.request("/api/sources", make_source("other"))
        for source in ("test", "other"):
            for offset in range(5):
                self.client.request("/api/collect", make_collection(source, offset))
        payload = make_collection("test", 5)
        payload["fields"] = payload["fields"][1:]
        self.client.request("/api/collect", payload)
        matches = self.client.request("/api/associate", {})["associations"]
        self.assertEqual(len(matches), 2)
class ParserTests(unittest.TestCase):
    def test_nested_text_comments_scripts_and_void_tags(self):
        html = '<div><script>ignored</script><template><span id="price">999</span></template><span id="price">1,<b>200</b><!-- ignored --></span><br/></div>'
        parser = parse_snapshot(html, ["price"])
        self.assertEqual(parser.extract("price")[0], "1,200")
    def test_invalid_analysis_settings(self):
        with self.assertRaises(ValueError):
            AnalysisSettings(association_threshold=2)
        with self.assertRaises(ValueError):
            AnalysisSettings(change_multiplier=float("nan"))
if __name__ == "__main__":
    unittest.main(verbosity=2)
