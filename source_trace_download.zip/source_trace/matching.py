# 跨站指标匹配模块
from collections import defaultdict
from .analysis import compare_events
from .errors import ApiError
def find_matches(database, settings):
    groups = defaultdict(list)
    source_cache = {}
    for field, source_id, _ in database.latest_fields():
        if source_id not in source_cache:
            source_cache[source_id] = database.get_source(source_id)
        source = source_cache[source_id]
        group = (source["region"], field["metric"], field["unit"], field["period"], field["context"])
        groups[group].append((field, source_id))
    pair_count = sum(len(group) * (len(group) - 1) // 2 for group in groups.values())
    if pair_count > 100000:
        raise ApiError("候选匹配规模超过单次处理上限", 413, "match_limit")
    matches = []
    for group in groups.values():
        for index, (left, left_source) in enumerate(group):
            for right, right_source in group[index + 1:]:
                if left_source == right_source:
                    continue
                start = max(left.get("window_start", "0001-01-01"), right.get("window_start", "0001-01-01"))
                end = min(left.get("window_end", left["date"]), right.get("window_end", right["date"]))
                left_events = [event for event in left["temporal"]["events"] if start < event["date"] <= end]
                right_events = [event for event in right["temporal"]["events"] if start < event["date"] <= end]
                metrics = compare_events(left_events, right_events)
                if metrics["samples"] >= settings.minimum_events and metrics["score"] >= settings.association_threshold:
                    match = {"left": left["id"], "right": right["id"], **metrics, "window_start": start, "window_end": end, "status": "candidate"}
                    match["criteria"] = {"minimum_events": settings.minimum_events, "score_threshold": settings.association_threshold}
                    database.add_link(left["id"], right["id"], "cross_source_candidate", match)
                    matches.append(match)
    return matches
