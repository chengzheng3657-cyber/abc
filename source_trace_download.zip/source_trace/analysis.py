# 序列分析模块
import math
import statistics
from dataclasses import dataclass
from .validation import hash_json
@dataclass(frozen=True)
class AnalysisSettings:
    minimum_events: int = 3
    date_threshold: float = 0.8
    direction_threshold: float = 0.8
    association_threshold: float = 0.6
    change_multiplier: float = 1.5
    relative_floor: float = 0.000001
    def __post_init__(self):
        if isinstance(self.minimum_events, bool) or not isinstance(self.minimum_events, int) or self.minimum_events < 2:
            raise ValueError("最小事件数量必须为不小于2的整数")
        values = (self.date_threshold, self.direction_threshold, self.association_threshold, self.change_multiplier, self.relative_floor)
        if any(isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) for value in values):
            raise ValueError("分析参数必须为有限数值")
        if any(not 0 <= value <= 1 for value in (self.date_threshold, self.direction_threshold, self.association_threshold)):
            raise ValueError("分析阈值配置无效")
        if self.change_multiplier <= 0 or self.relative_floor <= 0:
            raise ValueError("事件点幅度参数必须大于0")
def summarize_series(series, settings):
    observations = sorted(series.items())
    changes = [value - observations[index - 1][1] for index, (_, value) in enumerate(observations) if index]
    deviation = statistics.pstdev(changes) if changes else 0
    magnitude = max((abs(value) for _, value in observations), default=0)
    threshold = max(settings.change_multiplier * deviation, settings.relative_floor * magnitude)
    events = [{"date": observations[index + 1][0], "sign": 1 if change > 0 else -1} for index, change in enumerate(changes) if abs(change) > threshold]
    return {"events": events, "threshold": threshold, "signature": hash_json(events), "observations": len(observations)}
def compare_events(left_events, right_events):
    left = {event["date"]: event["sign"] for event in left_events}
    right = {event["date"]: event["sign"] for event in right_events}
    union = left.keys() | right.keys()
    intersection = left.keys() & right.keys()
    date_similarity = len(intersection) / len(union) if union else 0.0
    agreement = sum(left[key] == right[key] for key in intersection) / len(intersection) if intersection else 0.0
    return {"date_similarity": date_similarity, "direction_agreement": agreement, "score": date_similarity * agreement, "samples": len(union)}
def compare_field(current, previous, rules_comparable, settings, parser_comparable=True, settings_comparable=True):
    if previous is None:
        return {"type": "新增字段", "temporal_state": "不可判定", "structure_changed": False, "constraint_changed": False, "cause": "缺少历史对应字段", "changed_rules": [], "cochanged_fields": []}
    structure_changed = current["structure_hash"] != previous.get("structure_hash") if parser_comparable else None
    constraint_changed = current["constraint_hash"] != previous.get("constraint_hash") if parser_comparable else None
    start = max(current["window_start"], previous.get("window_start", current["window_start"]))
    end = min(current["window_end"], previous.get("window_end", current["window_end"]))
    left = [event for event in current["temporal"]["events"] if start < event["date"] <= end]
    right = [event for event in previous["temporal"]["events"] if start < event["date"] <= end]
    metrics = compare_events(left, right)
    if not settings_comparable or metrics["samples"] < settings.minimum_events:
        state = "不可判定"
    elif metrics["date_similarity"] >= settings.date_threshold and metrics["direction_agreement"] >= settings.direction_threshold:
        state = "稳定"
    else:
        state = "不稳定"
    changes = []
    if structure_changed:
        changes.append("布局调整")
    if constraint_changed:
        changes.append("业务约束变化")
    if state == "不稳定":
        changes.append("历史序列变化待复核")
    if not parser_comparable:
        kind = "解析版本变化，待复核"
    elif not settings_comparable:
        kind = "分析参数变化，待复核"
    elif not rules_comparable:
        kind = "规则版本变化，待复核"
    else:
        kind = "、".join(changes) or ("字段稳定" if state == "稳定" else "样本不足")
    old_status = {result["id"]: result["status"] for result in previous["constraints"]}
    changed_rules = [result["id"] for result in current["constraints"] if result["id"] in old_status and old_status[result["id"]] != result["status"]]
    return {"type": kind, "structure_changed": structure_changed, "constraint_changed": constraint_changed, "temporal_state": state, "metrics": metrics, "window_start": start, "window_end": end, "changed_rules": changed_rules, "cochanged_fields": [], "cause": "未发现足够证据确认业务含义改变"}
def explain_changes(fields, rules):
    by_key = {field["key"]: field for field in fields}
    by_rule = {rule["id"]: rule for rule in rules}
    for field in fields:
        report = field["drift"]
        peers = set()
        for rule_id in report["changed_rules"]:
            for key in by_rule[rule_id]["fields"]:
                peer = by_key.get(key)
                if peer and key != field["key"] and rule_id in peer["drift"]["changed_rules"]:
                    peers.add(key)
        report["cochanged_fields"] = sorted(peers)
        if peers:
            report["cause"] = "共享规则的校验状态变化；不能据此认定多个字段同时出错"
        elif report["changed_rules"]:
            report["cause"] = "字段校验状态变化，需结合原始页面复核"
