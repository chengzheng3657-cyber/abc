# 接口演示模块
import argparse
import json
import os
import sys
import tempfile
import threading
import uuid
from pathlib import Path
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "source_trace"
from .client import ApiClient
from .http_api import ApiServer
from .sample_data import make_collection, make_source
from .service import CollectionService
from .storage import Database
def require_result(condition, message):
    if not condition:
        raise RuntimeError(message)
def run_demo(client):
    run_id = uuid.uuid4().hex[:12]
    source_ids = ["demo-exchange-" + run_id, "demo-feed-" + run_id]
    initial_count = client.request("/api/verify")["checked_events"]
    latest = {}
    # 通过HTTP提交两组人工构造的页面快照
    print("正在提交接口演示数据", flush=True)
    for source_id in source_ids:
        client.request("/api/sources", make_source(source_id, "演示区域-" + run_id))
        for offset in range(7):
            payload = make_collection(source_id, offset, source_id == source_ids[0] and offset == 6)
            event = client.request("/api/collect", payload)
        latest[source_id] = event
    target = latest[source_ids[0]]
    total = next(field for field in target["fields"] if field["key"] == "total")
    matches = client.request("/api/associate", {})["associations"]
    final_fields = {field["id"] for event in latest.values() for field in event["fields"]}
    matches = [match for match in matches if match["left"] in final_fields and match["right"] in final_fields]
    trace = client.request("/api/trace", query={"entity": total["id"]})
    verification = client.request("/api/verify")
    require_result(target["checks"][0]["status"] == "violated", "未检出预期的电量平衡异常")
    require_result(total["drift"]["structure_changed"] and total["drift"]["constraint_changed"], "未检出预期的页面和校验变化")
    require_result(total["drift"]["temporal_state"] == "稳定", "共同日期范围内的事件序列应保持稳定")
    require_result(len(matches) == 3, "跨来源匹配结果不符合预期")
    require_result(verification["valid"] and verification["checked_events"] - initial_count == 14, "采集记录数量或完整性不符合预期")
    require_result(len(trace["events"]) == 14, "历史查询未返回完整记录")
    result = {
        "system": "来源追溯系统",
        "data_type": "synthetic",
        "collected_events": verification["checked_events"] - initial_count,
        "field_name": total["name"],
        "business_date": total["date"],
        "value": total["value"],
        "unit": total["unit"],
        "checks": target["checks"],
        "change_report": total["drift"],
        "candidate_matches": len(matches),
        "history_events": len(trace["events"]),
        "integrity_valid": verification["valid"],
    }
    # 输出接口返回结果的摘要
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result
def main():
    parser = argparse.ArgumentParser(description="通过HTTP执行来源追溯演示")
    parser.add_argument("--base-url")
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.base_url:
        result = run_demo(ApiClient(args.base_url, os.environ.get("TRACE_API_TOKEN")))
    else:
        with tempfile.TemporaryDirectory(prefix="source-trace-") as directory:
            database = Database(str(Path(directory) / "demo.sqlite3"))
            server = ApiServer(("127.0.0.1", 0), CollectionService(database))
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                client = ApiClient("http://127.0.0.1:" + str(server.server_port))
                result = run_demo(client)
            finally:
                server.shutdown()
                server.server_close()
                thread.join()
                database.close()
    if args.output:
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
if __name__ == "__main__":
    main()
