# 业务规则模块
from decimal import Decimal
from .errors import ApiError
from .validation import MAX_FIELDS, MAX_RULES, finite_number, hash_json, require_id, require_list, require_object
def validate_rules(raw_rules):
    rules, used_ids = [], set()
    for entry in require_list({"rules": raw_rules}, "rules", MAX_RULES):
        raw = require_object(entry, "规则")
        rule_id = require_id(raw, "id")
        rule_type = raw.get("type")
        fields = require_list(raw, "fields", MAX_FIELDS, allow_empty=False)
        if rule_id in used_ids or rule_type not in ("balance", "range", "equal") or len(fields) < 2:
            raise ApiError("规则编号重复、类型错误或参与字段不足")
        fields = [require_id({"key": field}, "key") for field in fields]
        if len(set(fields)) != len(fields) or rule_type == "range" and len(fields) != 3:
            raise ApiError("参与字段不得重复，range规则需三个字段")
        relative = finite_number(raw.get("relative_tolerance", 0.0001), "relative_tolerance")
        absolute = finite_number(raw.get("absolute_tolerance", 0.000001), "absolute_tolerance")
        if not 0 <= relative < 1 or absolute < 0:
            raise ApiError("相对容差须在[0,1)内，绝对容差不得为负数")
        used_ids.add(rule_id)
        rules.append({"id": rule_id, "type": rule_type, "fields": fields, "relative_tolerance": relative, "absolute_tolerance": absolute})
    return sorted(rules, key=lambda rule: rule["id"])
def evaluate_rules(fields, rules):
    by_key = {field["key"]: field for field in fields}
    results = []
    for rule in rules:
        participants = [by_key.get(key) for key in rule["fields"]]
        reason = None
        if any(field is None for field in participants):
            reason = "参与字段缺失"
        elif len({field["date"] for field in participants}) != 1:
            reason = "参与字段业务日期不一致"
        elif len({(field["unit"], field["period"]) for field in participants}) != 1:
            reason = "参与字段单位或时间粒度不一致"
        if reason:
            results.append({"id": rule["id"], "status": "unknown", "reason": reason})
            continue
        values = [Decimal(str(field["value"])) for field in participants]
        tolerance = max(Decimal(str(rule["absolute_tolerance"])), Decimal(str(rule["relative_tolerance"])) * max(map(abs, values)))
        if rule["type"] == "balance":
            residual = abs(values[0] - sum(values[1:]))
        elif rule["type"] == "range":
            residual = max(values[0] - values[1], values[1] - values[2], Decimal(0))
        else:
            residual = max(values) - min(values)
        results.append({"id": rule["id"], "status": "satisfied" if residual <= tolerance else "violated", "residual": float(residual), "tolerance": float(tolerance)})
    for field in fields:
        field_results, roles = [], []
        for rule, result in zip(rules, results):
            if field["key"] in rule["fields"]:
                field_results.append(result)
                roles.append([rule["id"], rule["type"], rule["fields"].index(field["key"])])
        field["constraints"] = field_results
        field["constraint_hash"] = hash_json([roles, [[result["id"], result["status"]] for result in field_results]])
    return results
