# HTTP接口模块
import logging
import secrets
import sqlite3
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from .errors import ApiError
from .validation import MAX_BODY_BYTES, decode_json, encode_json, require_text
LOGGER = logging.getLogger(__name__)
class ApiServer(ThreadingHTTPServer):
    daemon_threads = False
    def __init__(self, address, service, allowed_origins=(), token=None):
        self.service = service
        self.allowed_origins = frozenset(allowed_origins)
        self.token = token
        super().__init__(address, ApiHandler)
class ApiHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "SourceTrace/2"
    sys_version = ""
    def setup(self):
        super().setup()
        self.connection.settimeout(15)
    def log_message(self, message, *args):
        return
    def send_json(self, status, payload):
        body = encode_json(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Request-ID", self.request_id)
        origin = self.headers.get("Origin")
        if origin in self.server.allowed_origins:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
            self.send_header("Access-Control-Expose-Headers", "X-Request-ID")
        self.end_headers()
        self.close_connection = True
        if self.command != "HEAD":
            self.wfile.write(body)
    def read_payload(self):
        if self.headers.get("Transfer-Encoding") is not None:
            raise ApiError("不支持Transfer-Encoding", 400, "invalid_framing")
        lengths = self.headers.get_all("Content-Length", [])
        if not lengths:
            raise ApiError("缺少Content-Length", 411, "length_required")
        if len(lengths) != 1 or len(lengths[0]) > 12 or not lengths[0].isascii() or not lengths[0].isdigit():
            raise ApiError("Content-Length无效", 400, "invalid_framing")
        size = int(lengths[0])
        if not 0 < size <= MAX_BODY_BYTES:
            raise ApiError("请求体必须为1字节至2MB", 413, "body_too_large")
        if self.headers.get_content_type() != "application/json":
            raise ApiError("Content-Type必须为application/json", 415, "unsupported_media_type")
        raw = self.rfile.read(size)
        if len(raw) != size:
            raise ApiError("请求体不完整", 400, "incomplete_body")
        return decode_json(raw)
    def check_access(self):
        origin = self.headers.get("Origin")
        if origin and origin not in self.server.allowed_origins:
            raise ApiError("该前端来源未获准访问", 403, "origin_denied")
        if self.command == "OPTIONS" or not self.server.token:
            return
        supplied = self.headers.get("Authorization", "").encode("utf-8")
        expected = ("Bearer " + self.server.token).encode("utf-8")
        if not secrets.compare_digest(supplied, expected):
            raise ApiError("访问令牌无效", 401, "unauthorized")
    def query_value(self, query, key):
        values = query.get(key, [])
        if len(values) != 1:
            raise ApiError("查询参数缺失或重复: " + key)
        return require_text({key: values[0]}, key, 300)
    def route(self):
        path = urlsplit(self.path)
        query = parse_qs(path.query, keep_blank_values=True)
        service = self.server.service
        get_routes = ("/health", "/api/verify", "/api/trace", "/api/event")
        post_routes = ("/api/sources", "/api/collect", "/api/associate")
        if path.path not in get_routes + post_routes:
            raise ApiError("接口不存在", 404, "not_found")
        if self.command == "OPTIONS":
            return {"methods": ["GET"] if path.path in get_routes else ["POST"]}
        expected = "GET" if path.path in get_routes else "POST"
        if self.command != expected:
            raise ApiError("请求方法不支持", 405, "method_not_allowed")
        if self.command == "GET":
            if path.path == "/health":
                return {"status": "ok", "system": "来源追溯系统", "api_version": 2}
            if path.path == "/api/verify":
                return service.verify()
            if path.path == "/api/event":
                return service.get_event(self.query_value(query, "id"))
            return service.trace(self.query_value(query, "entity"))
        data = self.read_payload()
        if path.path == "/api/sources":
            return service.save_source(data)
        if path.path == "/api/collect":
            return service.collect(data)
        return {"associations": service.associate()}
    def handle_request(self):
        self.request_id = uuid.uuid4().hex
        try:
            self.check_access()
            result = self.route()
            status, payload = HTTPStatus.OK, {"data": result}
        except ApiError as error:
            status, payload = error.status, {"error": str(error), "code": error.code}
        except (TimeoutError, ConnectionError):
            status, payload = 408, {"error": "请求读取超时或连接中断", "code": "request_timeout"}
        except sqlite3.OperationalError as error:
            if "locked" in str(error).lower() or "busy" in str(error).lower():
                status, payload = 503, {"error": "数据库繁忙，请稍后重试", "code": "database_busy"}
            else:
                LOGGER.exception("database_failure request_id=%s", self.request_id)
                status, payload = 500, {"error": "数据库处理失败", "code": "database_error"}
        except Exception:
            LOGGER.exception("request_failure request_id=%s", self.request_id)
            status, payload = 500, {"error": "内部处理失败", "code": "internal_error"}
        try:
            self.send_json(status, payload)
        except (ConnectionError, OSError):
            self.close_connection = True
    do_GET = handle_request
    do_POST = handle_request
    do_OPTIONS = handle_request
    do_PUT = handle_request
    do_DELETE = handle_request
    do_PATCH = handle_request
    do_HEAD = handle_request
