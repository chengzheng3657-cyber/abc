# HTTP端口服务模块
import argparse
import logging
import os
import sys
from pathlib import Path
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "source_trace"
from .analysis import AnalysisSettings
from .http_api import ApiServer
from .service import CollectionService
from .storage import Database
def main():
    parser = argparse.ArgumentParser(description="来源追溯系统HTTP服务")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default="source_trace.sqlite3")
    parser.add_argument("--allow-origin", action="append", default=[])
    parser.add_argument("--minimum-events", type=int, default=3)
    parser.add_argument("--association-threshold", type=float, default=0.6)
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    try:
        settings = AnalysisSettings(minimum_events=args.minimum_events, association_threshold=args.association_threshold)
    except ValueError as error:
        parser.error(str(error))
    database = Database(args.db)
    server = None
    try:
        server = ApiServer((args.host, args.port), CollectionService(database, settings), args.allow_origin, os.environ.get("TRACE_API_TOKEN"))
        # 监听地址由操作系统分配完成后再报告启动成功
        print("来源追溯系统已启动，监听端口", server.server_port, flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
    finally:
        if server is not None:
            server.server_close()
        database.close()
if __name__ == "__main__":
    main()
