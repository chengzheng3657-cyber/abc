# 测试数据模块
from datetime import date, timedelta
def make_source(source_id, region="测试省"):
    return {
        "id": source_id,
        "name": "接口测试来源",
        "region": region,
        "rules": [{"id": "energy-balance", "type": "balance", "fields": ["total", "ahead", "realtime"]}],
    }
def make_collection(source_id, offset, invalid_total=False):
    values = {"total": 100 + offset * 10, "ahead": 60 + offset * 6, "realtime": 40 + offset * 4}
    if invalid_total:
        values["total"] += 7
    cells = "".join(f'<td id="{key}">{value}</td>' for key, value in values.items())
    table = '<table><tr><th>电量</th></tr><tr>' + cells + '</tr></table>'
    if invalid_total:
        table = "<section>" + table + "</section>"
    business_date = (date(2026, 11, 1) + timedelta(days=offset)).isoformat()
    fields = []
    for key, name in (("total", "总出清电量"), ("ahead", "日前出清电量"), ("realtime", "实时出清电量")):
        fields.append({"key": key, "name": name, "context": "省级电量日报", "unit": "MWh", "metric": key, "date": business_date, "element_id": key})
    return {
        "source_id": source_id,
        "page_id": "daily-energy",
        "request_id": f"{source_id}-{offset}",
        "html": "<html><body>" + table + "</body></html>",
        "fields": fields,
    }
