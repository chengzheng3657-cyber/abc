# 请求校验模块
import hashlib
import json
import math
import re
from datetime import date
from .errors import ApiError
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,99}\Z")
NUMBER_TEXT = re.compile(r"[+-]?(?:(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?\Z", re.ASCII)
MAX_FIELDS = 128
MAX_RULES = 128
MAX_BODY_BYTES = 2 * 1024 * 1024
def encode_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
def hash_json(value):
    return hashlib.sha256(encode_json(value).encode("utf-8")).hexdigest()
def reject_constant(value):
    raise ApiError("JSON不允许非有限数值")
def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ApiError("JSON存在重复键: " + key)
        result[key] = value
    return result
def decode_json(raw):
    try:
        result = json.loads(raw.decode("utf-8"), parse_constant=reject_constant, object_pairs_hook=unique_object)
    except (UnicodeDecodeError, ValueError, RecursionError) as error:
        raise ApiError("请求体不是有效的UTF-8 JSON") from error
    pending = [(result, 0)]
    while pending:
        value, depth = pending.pop()
        if depth > 64:
            raise ApiError("JSON嵌套深度超过64")
        if isinstance(value, str) and any(0xD800 <= ord(character) <= 0xDFFF for character in value):
            raise ApiError("JSON包含无效Unicode字符")
        if isinstance(value, float) and not math.isfinite(value):
            raise ApiError("JSON不允许非有限数值")
        if isinstance(value, dict):
            pending.extend((item, depth + 1) for pair in value.items() for item in pair)
        elif isinstance(value, list):
            pending.extend((item, depth + 1) for item in value)
    return require_object(result, "请求体")
def require_object(value, label):
    if not isinstance(value, dict):
        raise ApiError(label + "必须为对象")
    return value
def require_text(data, key, limit=200):
    value = data.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ApiError(key + "必须为非空字符串，最大长度" + str(limit))
    if any(ord(character) < 32 for character in value):
        raise ApiError(key + "不允许控制字符")
    return value.strip()
def require_id(data, key):
    value = require_text(data, key, 100)
    if not IDENTIFIER.fullmatch(value):
        raise ApiError(key + "只能包含字母、数字、点、下划线和连字符")
    return value
def require_list(data, key, limit, allow_empty=True):
    value = data.get(key)
    if not isinstance(value, list) or len(value) > limit or not allow_empty and not value:
        raise ApiError(key + "必须为列表，长度上限" + str(limit))
    return value
def finite_number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ApiError(label + "必须为数值")
    try:
        result = float(value)
    except (ValueError, OverflowError) as error:
        raise ApiError(label + "不是有效数值") from error
    if not math.isfinite(result) or abs(result) > 1e100:
        raise ApiError(label + "必须为绝对值不超过1e100的有限数值")
    return result
def parse_number(text):
    value = text.strip().replace("\N{MINUS SIGN}", "-")
    if not NUMBER_TEXT.fullmatch(value):
        raise ApiError("字段文本不是有效数值: " + value[:80])
    return finite_number(value.replace(",", ""), "字段值")
def require_date(data, key):
    value = require_text(data, key, 10)
    try:
        parsed = date.fromisoformat(value)
    except ValueError as error:
        raise ApiError(key + "必须为YYYY-MM-DD日期") from error
    if parsed.isoformat() != value:
        raise ApiError(key + "必须为YYYY-MM-DD日期")
    return value
