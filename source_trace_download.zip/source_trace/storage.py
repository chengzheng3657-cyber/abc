# 数据存储模块
import json
import sqlite3
import threading
from contextlib import contextmanager
from .errors import NotFoundError
from .validation import encode_json, hash_json
class Database:
    def __init__(self, path):
        self.lock = threading.RLock()
        self.connection = sqlite3.connect(path, timeout=15, isolation_level=None, check_same_thread=False)
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.execute("PRAGMA busy_timeout=15000")
        self.connection.executescript("""CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, source TEXT NOT NULL REFERENCES sources(id), page TEXT NOT NULL, request_key TEXT NOT NULL, request_hash TEXT NOT NULL, payload TEXT NOT NULL, UNIQUE(source,page,request_key));
CREATE TABLE IF NOT EXISTS links(id TEXT PRIMARY KEY, upstream TEXT NOT NULL, downstream TEXT NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS field_records(id TEXT PRIMARY KEY, event_id TEXT NOT NULL REFERENCES events(id), stable_id TEXT NOT NULL, payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS events_page_idx ON events(source,page,seq);
CREATE INDEX IF NOT EXISTS fields_event_idx ON field_records(event_id);
CREATE INDEX IF NOT EXISTS fields_stable_idx ON field_records(stable_id);
CREATE INDEX IF NOT EXISTS links_upstream_idx ON links(upstream);
CREATE INDEX IF NOT EXISTS links_downstream_idx ON links(downstream);""")
        with self.transaction():
            missing = self.connection.execute("SELECT payload FROM events WHERE NOT EXISTS(SELECT 1 FROM field_records WHERE event_id=events.id)").fetchall()
            for row in missing:
                self.insert_fields(json.loads(row[0]))
    @contextmanager
    def transaction(self, write=True):
        with self.lock:
            self.connection.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            try:
                yield
                self.connection.commit()
            except BaseException:
                self.connection.rollback()
                raise
    def close(self):
        with self.lock:
            self.connection.close()
    def get_source(self, source_id):
        row = self.connection.execute("SELECT payload FROM sources WHERE id=?", (source_id,)).fetchone()
        if row is None:
            raise NotFoundError("来源不存在")
        return json.loads(row[0])
    def save_source(self, source):
        self.connection.execute("INSERT INTO sources(id,payload) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload", (source["id"], encode_json(source)))
    def find_request(self, source_id, page_id, request_id):
        row = self.connection.execute("SELECT request_hash,payload FROM events WHERE source=? AND page=? AND request_key=?", (source_id, page_id, request_id)).fetchone()
        return (row[0], json.loads(row[1])) if row else None
    def get_event(self, event_id):
        row = self.connection.execute("SELECT payload FROM events WHERE id=?", (event_id,)).fetchone()
        if row is None:
            raise NotFoundError("采集记录不存在")
        return json.loads(row[0])
    def latest_event(self, source_id, page_id):
        row = self.connection.execute("SELECT payload FROM events WHERE source=? AND page=? ORDER BY seq DESC LIMIT 1", (source_id, page_id)).fetchone()
        return json.loads(row[0]) if row else None
    def field_history(self, source_id, page_id):
        rows = self.connection.execute("SELECT field_records.payload FROM field_records JOIN events ON field_records.event_id=events.id WHERE source=? AND page=? ORDER BY seq", (source_id, page_id))
        history = {}
        for row in rows:
            field = json.loads(row[0])
            history.setdefault(field["stable_id"], []).append(field)
        return history
    def insert_fields(self, event):
        self.connection.executemany("INSERT INTO field_records(id,event_id,stable_id,payload) VALUES(?,?,?,?)", [(field["id"], event["id"], field["stable_id"], encode_json(field)) for field in event["fields"]])
    def save_event(self, event, request_id, request_hash):
        self.connection.execute("INSERT INTO events(id,source,page,request_key,request_hash,payload) VALUES(?,?,?,?,?,?)", (event["id"], event["source_id"], event["page_id"], request_id, request_hash, encode_json(event)))
        self.insert_fields(event)
    def iter_event_records(self):
        return self.connection.execute("SELECT id,source,page,payload FROM events ORDER BY seq")
    def add_link(self, upstream, downstream, kind, details=None):
        link_id = hash_json([upstream, downstream, kind])
        link = {"id": link_id, "upstream": upstream, "downstream": downstream, "kind": kind, "details": details or {}}
        self.connection.execute("INSERT OR IGNORE INTO links(id,upstream,downstream,kind,payload) VALUES(?,?,?,?,?)", (link_id, upstream, downstream, kind, encode_json(link)))
    def adjacent_links(self, entity):
        rows = self.connection.execute("SELECT payload FROM links WHERE downstream=? OR (upstream=? AND kind IN ('cross_source_candidate','跨源候选关联'))", (entity, entity))
        return [json.loads(row[0]) for row in rows]
    def latest_fields(self):
        rows = self.connection.execute("SELECT field_records.payload,events.source,events.page FROM field_records JOIN events ON event_id=events.id WHERE NOT EXISTS(SELECT 1 FROM events newer WHERE newer.source=events.source AND newer.page=events.page AND newer.seq>events.seq) ORDER BY events.source,events.page,field_records.id")
        return [(json.loads(payload), source, page) for payload, source, page in rows]
