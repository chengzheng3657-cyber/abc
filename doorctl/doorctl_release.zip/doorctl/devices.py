# 设备注册表
import time
import math
DEFAULTS = dict(
    interval_us=1600, pulse_us=100, frame_gap_us=10000,
    average_low=50, average_high=200, maximum_low=100, maximum_high=400,
    window=15, power_min=0, power_max=15,
    power_interval_s=30, power_save_s=60,
    start_timeout_s=1, motion_timeout_s=2, query_timeout_s=1,
    heartbeat_s=10, offline_s=30,
    light_s=60, door_alarm_s=30, allow_double_open=False,
)
class DeviceRegistry:
    def __init__(self, store):
        self.store = store
        saved = store.get("config", "system", {})
        migrated = saved.pop("power_initial", None) is not None
        self.config = dict(DEFAULTS, **saved)
        self.items = store.all("device")
        self.seen = {}
        self.validate(self.config)
        if migrated:
            self.store.put("config", "system", self.config)
            self.store.event("config_migrated", {"removed": ["power_initial"]})
        for address, item in self.items.items():
            if "correlation_validated" in item:
                item.pop("correlation_validated")
                self.store.put("device", address, item)
                self.store.event("device_migrated", {"address": address})
    def validate(self, c):
        for name in ("interval_us", "pulse_us", "frame_gap_us", "window", "power_min", "power_max"):
            if type(c.get(name)) is not int:
                raise ValueError("参数必须是整数: " + name)
        if set(c) != set(DEFAULTS):
            raise ValueError("未知配置项")
        for k, v in c.items():
            if k == "allow_double_open":
                if type(v) is not bool:
                    raise ValueError("双开配置必须是布尔值")
            elif type(v) not in (int, float) or not math.isfinite(v) or not 0 < v < 10000000:
                if not (k == "power_min" and type(v) is int and v == 0):
                    raise ValueError("参数超出范围: " + k)
        if not (c["average_low"] < c["average_high"] and c["maximum_low"] < c["maximum_high"] and 0 <= c["power_min"] <= c["power_max"] <= 15):
            raise ValueError("阈值或功率范围错误")
        if type(c["window"]) is not int or not 10 <= c["window"] <= 20 or not c["pulse_us"] < c["interval_us"] < c["frame_gap_us"] or c["offline_s"] <= c["heartbeat_s"]:
            raise ValueError("窗口或时间参数错误")
    def configure(self, changes):
        if not isinstance(changes, dict):
            raise ValueError("配置必须是对象")
        c = dict(self.config, **changes)
        self.validate(c)
        self.store.put("config", "system", c)
        self.config = c
        return c
    def register(self, item):
        if not isinstance(item, dict):
            raise ValueError("设备资料必须是对象")
        allowed = {"address", "kind", "door", "direction", "rf", "power_supported"}
        if set(item) - allowed:
            raise ValueError("未知设备字段")
        address, kind, door = item.get("address"), item.get("kind"), item.get("door")
        if type(address) is not int or not 1 <= address <= 247 or kind not in ("lock", "reader") or door not in ("outer", "inner"):
            raise ValueError("设备注册字段错误")
        if item.get("direction", "normal") not in ("normal", "reverse"):
            raise ValueError("安装方向错误")
        for flag in ("rf", "power_supported"):
            if flag in item and type(item[flag]) is not bool:
                raise ValueError("设备能力字段错误")
        key = str(address)
        if key in self.items and self.items[key] != item:
            raise ValueError("设备地址冲突，请先核对设备配置")
        if any(x["kind"] == kind and x["door"] == door and x["address"] != address for x in self.items.values()):
            raise ValueError("门体设备映射冲突")
        if self.items.get(key) != item:
            self.store.put("device", key, item)
        self.items[key] = dict(item)
        self.touch(address)
        return item
    def touch(self, address):
        if str(address) not in self.items:
            raise ValueError("设备未注册")
        self.seen[address] = time.monotonic()
    def online(self, address):
        return time.monotonic() - self.seen.get(address, float("-inf")) < self.config["offline_s"]
    def find(self, kind, door, require_online=True):
        matches = [x for x in self.items.values() if x["kind"] == kind and x["door"] == door]
        if not matches or (require_online and not self.online(matches[0]["address"])):
            raise ValueError("设备离线或未注册")
        return matches[0]
