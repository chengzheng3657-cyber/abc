# 端口客户端
import asyncio
import contextlib
import secrets
import ssl
from validation import loads, dumps
class RpcClient:
    def __init__(self):
        self.pending = {}
        self.on_push = None
        self.send_lock = asyncio.Lock()
        self.push_tasks = set()
        self.task = None
        self.writer = None
        self.closed = False
    async def connect(self, host, port, role, token, cafile=None):
        if self.writer is not None:
            raise RuntimeError("客户端实例不能重复连接")
        tls = ssl.create_default_context(cafile=cafile) if cafile else None
        async with asyncio.timeout(5):
            self.reader, self.writer = await asyncio.open_connection(host, port, limit=65536, ssl=tls)
            try:
                await self.send(dict(role=role, token=token))
                reply = loads(await self.reader.readline())
                if reply.get("ok") is not True:
                    raise PermissionError(reply.get("error", "认证失败"))
            except BaseException:
                self.writer.close()
                await self.writer.wait_closed()
                raise
        self.task = asyncio.create_task(self.receive())
        return self
    async def send(self, message):
        async with self.send_lock:
            if self.closed or self.writer is None:
                raise ConnectionError("连接未建立或已经关闭")
            self.writer.write((dumps(message) + "\n").encode())
            await asyncio.wait_for(self.writer.drain(), 5)
    def push_done(self, task):
        self.push_tasks.discard(task)
        if not task.cancelled() and task.exception() is not None and self.writer:
            self.writer.close()
    async def receive(self):
        try:
            while raw := await self.reader.readline():
                message = loads(raw)
                response_id = message.get("id")
                if response_id is not None and not isinstance(response_id, str):
                    raise ValueError("响应ID类型错误")
                future = self.pending.get(response_id)
                if future and not future.done():
                    future.set_result(message)
                elif message.get("type") and self.on_push:
                    if len(self.push_tasks) >= 32:
                        raise ConnectionError("设备处理队列已满")
                    task = asyncio.create_task(self.on_push(message))
                    self.push_tasks.add(task)
                    task.add_done_callback(self.push_done)
        except (ValueError, RecursionError, ConnectionError):
            pass
        finally:
            self.closed = True
            for future in self.pending.values():
                if not future.done():
                    future.set_exception(ConnectionError("服务连接断开"))
            if self.writer:
                self.writer.close()
    async def request(self, op, request_id=None, timeout=15, **data):
        if len(self.pending) >= 32:
            raise RuntimeError("并发请求数量超限")
        request_id = request_id or secrets.token_hex(16)
        if request_id in self.pending:
            raise ValueError("请求ID正在使用")
        future = asyncio.get_running_loop().create_future()
        self.pending[request_id] = future
        try:
            await self.send(dict(data, op=op, id=request_id))
            reply = await asyncio.wait_for(future, timeout)
            if reply.get("ok") is not True:
                raise ValueError(reply.get("error", "请求失败"))
            return reply["data"]
        finally:
            self.pending.pop(request_id, None)
            if not future.done():
                future.cancel()
            elif not future.cancelled():
                future.exception()
    async def close(self):
        self.closed = True
        tasks = list(self.push_tasks)
        if self.task:
            tasks.append(self.task)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if self.writer:
            self.writer.close()
            with contextlib.suppress(ConnectionError):
                await self.writer.wait_closed()
