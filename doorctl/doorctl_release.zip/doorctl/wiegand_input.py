# 韦根输入处理
class PulseDecoder:
    def receive(self, pulses, config):
        if not isinstance(pulses, list) or len(pulses) != 26:
            raise ValueError("脉冲帧必须恰好26位，残帧和超长帧已丢弃")
        bits, times = [], []
        for pulse in pulses:
            line, tick = pulse.get("line"), pulse.get("tick_us")
            if line not in ("D0", "D1") or type(tick) is not int or not 0 <= tick < 1 << 32:
                raise ValueError("脉冲引脚或计时值错误")
            if times:
                delta = (tick - times[-1]) % (1 << 32)
                if not config["pulse_us"] <= delta < config["frame_gap_us"]:
                    raise ValueError("脉冲重叠、乱序或帧间超时")
            bits.append(int(line == "D1"))
            times.append(tick)
        return bits, times
