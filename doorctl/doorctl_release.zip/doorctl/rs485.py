# RS-485链路
import asyncio
from validation import loads, dumps
import secrets
import time
class FrameCodec:
    @staticmethod
    def encode(address, command, data):
        payload = dumps(data).encode()
        if type(address) is not int or type(command) is not int or not 1 <= address <= 247 or not 0 <= command <= 255 or len(payload) > 240:
            raise ValueError("总线字段超限")
        body = bytes((address, command, len(payload))) + payload
        return (b"\xaa" + body + bytes((sum(body) & 255, 0x55))).hex()
    @staticmethod
    def decode(raw):
        packet = bytes.fromhex(raw)
        if len(packet) < 8 or packet[0] != 0xAA or packet[-1] != 0x55 or packet[3] > 240 or len(packet) != packet[3] + 6 or (sum(packet[1:-2]) & 255) != packet[-2]:
            raise ValueError("总线帧边界、长度或校验和错误")
        if not 1 <= packet[1] <= 247:
            raise ValueError("设备地址错误")
        data = loads(packet[4:-2])
        return packet[1], packet[2], data
class FrameStream:
    def __init__(self):
        self.buffer = bytearray()
        self.last = 0
        self.rejected = 0
    def feed(self, raw):
        chunk = bytes.fromhex(raw)
        if len(chunk) > 4096:
            raise ValueError("总线输入块超限")
        now = time.monotonic()
        if now - self.last > 1:
            self.buffer.clear()
        self.last = now
        self.buffer.extend(chunk)
        frames = []
        while self.buffer:
            if self.buffer[0] != 0xAA:
                del self.buffer[0]
                self.rejected += 1
                continue
            if len(self.buffer) < 4:
                break
            size = self.buffer[3] + 6
            if size > 246:
                del self.buffer[0]
                self.rejected += 1
                continue
            if len(self.buffer) < size:
                break
            packet = self.buffer[:size].hex()
            try:
                FrameCodec.decode(packet)
            except (ValueError, UnicodeError):
                del self.buffer[0]
                self.rejected += 1
                continue
            frames.append(packet)
            del self.buffer[:size]
        return frames
class BusLink:
    def __init__(self, devices):
        self.devices = devices
        self.gateway = None
        self.pending = {}
        self.event_handler = None
        self.silent = set()
        self.send_lock = asyncio.Lock()
        self.transaction_lock = asyncio.Lock()
        self.stream = FrameStream()
    async def request(self, address, command, data=None, timeout=1):
        async with asyncio.timeout(timeout):
            async with self.transaction_lock:
                return await self.exchange(address, command, data, timeout)
    async def exchange(self, address, command, data, timeout):
        if self.gateway is None:
            raise ConnectionError("硬件网关未连接")
        seq = secrets.token_hex(6)
        future = asyncio.get_running_loop().create_future()
        self.pending[seq] = (address, command | 0x80, future)
        try:
            async with self.send_lock:
                await self.gateway({"type": "bus_tx", "frame": FrameCodec.encode(address, command, dict(data or {}, seq=seq))})
            result = await asyncio.wait_for(future, timeout)
            if result.get("ok") is not True:
                raise ValueError("设备拒绝命令")
            return result
        finally:
            self.pending.pop(seq, None)
            if not future.done():
                future.cancel()
    async def receive(self, raw):
        for frame in self.stream.feed(raw):
            await self.receive_frame(frame)
    async def receive_frame(self, raw):
        address, command, data = FrameCodec.decode(raw)
        if command & 0x80:
            sequence = data.get("seq")
            if not isinstance(sequence, str):
                raise ValueError("应答序列号无效")
            entry = self.pending.get(sequence)
            if entry and entry[:2] == (address, command) and not entry[2].done():
                self.devices.touch(address)
                entry[2].set_result(data)
            return
        self.devices.touch(address)
        if address in self.silent and command not in (0x08, 0x09):
            return
        if self.event_handler:
            await self.event_handler(address, command, data)
    def disconnect(self):
        self.gateway = None
        self.stream = FrameStream()
        self.devices.seen.clear()
        for _, _, future in self.pending.values():
            if not future.done():
                future.set_exception(ConnectionError("硬件网关断开"))
