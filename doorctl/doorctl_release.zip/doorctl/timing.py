# 输入时序统计
class TimingMonitor:
    def evaluate(self, times, config):
        if len(times) != 26:
            raise ValueError("时序统计需要26个有效时间戳")
        deviations = [abs((b - a) % (1 << 32) - config["interval_us"]) for a, b in zip(times, times[1:])]
        average, maximum = sum(deviations) / len(deviations), max(deviations)
        if average > config["average_high"] or maximum >= config["maximum_high"]:
            level = "较差"
        elif average < config["average_low"] and maximum < config["maximum_low"]:
            level = "良好"
        else:
            level = "一般"
        return dict(average_us=average, maximum_us=maximum, level=level, metric="wiegand_timing")
