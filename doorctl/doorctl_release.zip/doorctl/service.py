# 门禁服务入口
import argparse
import asyncio
import contextlib
import hmac
import hashlib
import ssl
from validation import loads, dumps, integer, canonical
import os
from pathlib import Path
from store import StateStore
from devices import DeviceRegistry
from wiegand_input import PulseDecoder
from wiegand_codec import Wiegand26
from timing import TimingMonitor
from access import AccessRules
from rs485 import BusLink
from rf_control import ReaderPower
from interlock import DoorInterlock
from locks import DoorLocks
from recovery import LockRecovery
from telemetry import EventLog
REQUEST_FIELDS = {
    "register": {"device"},
    "bus_rx": {"frame"},
    "scan": {"capture_id", "door", "reader", "method", "pulses"},
    "status": set(),
    "grant": {"user_id", "doors"},
    "configure": {"changes"},
    "reader_policy": {"address", "enabled", "calibration_ref"},
    "button": {"key"},
    "events": {"after"},
    "ack_events": {"ids"},
}
class DoorService:
    def __init__(self, database):
        self.store = StateStore(database)
        self.devices = DeviceRegistry(self.store)
        self.ops = EventLog(self.store, self.devices)
        self.bus = BusLink(self.devices)
        self.locks = DoorLocks(self.devices, self.bus, self.ops)
        self.permissions = AccessRules(self.store)
        self.interlock = DoorInterlock(self.store)
        self.pulses, self.validator, self.quality = PulseDecoder(), Wiegand26(), TimingMonitor()
        self.power = ReaderPower(self.store, self.devices, self.bus, self.ops)
        self.fault = LockRecovery(self.locks, self.ops)
        self.clients = set()
        self.tasks = set()
        self.request_guard = asyncio.Lock()
        self.connection_limit = asyncio.Semaphore(64)
    async def open(self, door, source, user_id=None):
        async with self.interlock.guard:
            if user_id is not None and not self.permissions.check(user_id, door):
                return dict(success=False, result="PERMISSION_DENIED", door=door)
            allowed, reason = await self.interlock.check(door, self.locks.query)
            if not allowed:
                self.ops.voice = reason
                self.ops.record("interlock_denied", dict(door=door, source=source, user_id=user_id, reason=reason))
                return dict(success=False, result="INTERLOCK_DENIED", reason=reason, door=door)
            try:
                result = await self.locks.move(door)
                result = await self.fault.recover(result)
            except (ValueError, TimeoutError, ConnectionError) as error:
                self.ops.alarm("CONTROL_ERROR", dict(door=door, reason=str(error)))
                return dict(success=False, result="CONTROL_ERROR", door=door, reason=str(error))
            if result["success"]:
                self.ops.passage(door)
                print("通行控制:", door, result["result"], flush=True)
            self.ops.record("access_result", dict(result, source=source, user_id=user_id))
            return result
    async def secure(self, door):
        async with self.interlock.guard:
            try:
                state = await self.locks.query(door)
            except (ValueError, TimeoutError, ConnectionError):
                self.ops.alarm("STATE_UNKNOWN", dict(door=door))
                return dict(success=False, result="STATE_UNKNOWN", door=door, state=None)
            if not state["door_closed"]:
                return dict(success=False, result="DOOR_NOT_CLOSED", door=door)
            result = await self.fault.recover(await self.locks.move(door, unlock=False))
            if result["success"]:
                self.interlock.release(door, await self.locks.query(door))
            self.ops.record("secure_result", result)
            return result
    async def dispatch(self, role, message):
        op = message.get("op")
        if not isinstance(op, str) or op not in REQUEST_FIELDS:
            raise ValueError("未知操作")
        if set(message) - REQUEST_FIELDS[op] - {"id", "op"}:
            raise ValueError("请求包含未定义字段")
        if role == "gateway":
            if op == "register":
                try:
                    return self.devices.register(message["device"])
                except ValueError as error:
                    self.ops.alarm("DEVICE_REGISTRATION_ERROR", dict(reason=str(error)))
                    raise
            if op == "bus_rx":
                await self.bus.receive(message["frame"])
                return dict(accepted=True)
            raise ValueError("网关操作不受支持")
        if op == "scan" and role != "collector":
            raise PermissionError("身份采集仅允许采集端提交")
        if role == "collector" and op != "scan":
            raise PermissionError("采集端仅允许提交身份帧")
        if role == "platform":
            if op == "events":
                return self.store.events(integer(message.get("after", 0), 0, 2**63 - 1, "事件游标"), True)
            if op == "ack_events":
                ids = message["ids"]
                if not isinstance(ids, list) or len(ids) > 200 or any(type(i) is not int for i in ids):
                    raise ValueError("事件确认列表无效")
                self.store.ack(ids)
                return dict(accepted=True)
            raise PermissionError("平台仅允许读取和确认运维事件")
        if op in ("grant", "configure", "button", "reader_policy") and role != "admin":
            raise PermissionError("需要管理权限")
        if op == "reader_policy":
            if self.power.lock.locked():
                raise ValueError("读卡器配置处理中")
            return self.power.configure(message["address"], message["enabled"], message.get("calibration_ref", ""))
        if op == "grant":
            result = self.permissions.grant(message["user_id"], message["doors"])
            self.ops.record("permission_changed", result)
            return result
        if op == "configure":
            if self.interlock.guard.locked() or self.power.lock.locked():
                raise ValueError("门锁动作期间不可修改配置")
            result = self.devices.configure(message["changes"])
            self.ops.record("configuration_changed", message["changes"])
            return result
        if op == "scan":
            door = message["door"]
            if door not in ("outer", "inner") or message.get("method") not in ("card", "fingerprint", "face", "iris"):
                raise ValueError("门体或识别方式错误")
            capture_id = message.get("capture_id")
            if not isinstance(capture_id, str) or not 16 <= len(capture_id) <= 64:
                raise ValueError("采集帧必须包含16至64字符的唯一capture_id")
            if self.store.get("capture", capture_id) is not None:
                raise ValueError("采集帧已处理，拒绝重复采集标识")
            reader = self.devices.find("reader", door)
            if type(message.get("reader")) is not int or message["reader"] != reader["address"]:
                raise ValueError("身份来源设备不匹配")
            self.store.put("capture", capture_id, dict(reader=reader["address"]))
            self.devices.touch(reader["address"])
            try:
                bits, times = self.pulses.receive(message["pulses"], self.devices.config)
                user_id = self.validator.validate(bits)
            except (ValueError, TypeError, AttributeError) as error:
                self.ops.record("wiegand_error", dict(reason=str(error)))
                return dict(success=False, result="INVALID_FRAME", reason=str(error))
            quality = self.quality.evaluate(times, self.devices.config)
            self.ops.record("timing_quality", dict(reader=reader["address"], **quality))
            try:
                power = await self.power.sample(reader, quality, message["method"])
            except (ValueError, TimeoutError, ConnectionError) as error:
                self.ops.alarm("POWER_ERROR", dict(reason=str(error)))
                power = dict(mode="error", reason=str(error))
            if not self.permissions.check(user_id, door):
                self.ops.voice = "验证失败"
                self.ops.record("permission_denied", dict(user_id=user_id, door=door))
                result = dict(success=False, result="PERMISSION_DENIED", door=door)
            else:
                self.ops.voice = ""
                result = await self.open(door, "identity", user_id)
            return dict(result, user_id=user_id, quality=quality, power=power)
        if op == "button":
            key = message["key"]
            if key not in ("inner_open", "outer_open", "double_open", "double_lock", "clear_alarm"):
                raise ValueError("未知按键")
            if not self.ops.debounce("admin", key):
                return dict(result="DEBOUNCED")
            self.ops.record("button", dict(key=key, source="authenticated_admin"))
            if key == "clear_alarm":
                self.ops.alarmed, self.ops.voice = False, ""
                return dict(result="ALARM_CLEARED")
            if key == "double_lock":
                return [await self.secure(door) for door in ("outer", "inner")]
            if key == "double_open":
                if not self.devices.config["allow_double_open"]:
                    raise PermissionError("特殊双开模式未启用")
                async with self.interlock.guard:
                    if self.interlock.occupied:
                        raise ValueError("存在未完成通行，不能切换双开模式")
                    self.interlock.reserve(("outer", "inner"))
                    self.ops.record("interlock_override", dict(source="authenticated_admin"))
                    results = []
                    for door in ("outer", "inner"):
                        result = await self.fault.recover(await self.locks.move(door))
                        results.append(result)
                        if not result["success"]:
                            break
                        self.ops.passage(door)
                    return results
            return await self.open("inner" if key == "inner_open" else "outer", "admin_button")
        if op == "status":
            states = {}
            async with self.interlock.guard:
                for door in ("outer", "inner"):
                    try:
                        states[door] = await self.locks.query(door)
                        self.ops.observe(door, states[door])
                        self.interlock.release(door, states[door])
                    except (ValueError, TimeoutError, ConnectionError):
                        states[door] = dict(phase="unknown")
            return dict(doors=states, occupied=sorted(self.interlock.occupied), operations=self.ops.status(), rejected_bus_bytes=self.bus.stream.rejected)
        if op == "events" and role == "admin":
            return self.store.events(integer(message.get("after", 0), 0, 2**63 - 1, "事件游标"))
        raise ValueError("未知操作")
    async def handle_request(self, role, request_id, message):
        mutating = message.get("op") in ("scan", "button", "grant", "configure", "reader_policy")
        if not mutating:
            return dict(id=request_id, ok=True, data=await self.dispatch(role, message))
        digest = hashlib.sha256(canonical(message).encode()).hexdigest()
        async with self.request_guard:
            existing = self.store.begin_request(role, request_id, digest)
            if existing is not None:
                return existing
            try:
                response = dict(id=request_id, ok=True, data=await self.dispatch(role, message))
            except (ValueError, KeyError, TypeError, AttributeError, PermissionError, TimeoutError, ConnectionError) as error:
                response = dict(id=request_id, ok=False, error=str(error))
            self.store.finish_request(role, request_id, digest, response)
            return response
    async def maintain(self):
        while True:
            await asyncio.sleep(self.devices.config["heartbeat_s"])
            await self.power.persist_stable()
            if self.interlock.guard.locked():
                continue
            async with self.interlock.guard:
                for door in ("outer", "inner"):
                    try:
                        state = await self.locks.query(door)
                        self.ops.observe(door, state)
                        self.interlock.release(door, state)
                    except (ValueError, TimeoutError, ConnectionError) as error:
                        self.ops.alarm("HEARTBEAT_ERROR", dict(door=door, reason=str(error)))
                for item in list(self.devices.items.values()):
                    if item["kind"] == "reader":
                        try:
                            await self.bus.request(item["address"], 0x01, timeout=self.devices.config["query_timeout_s"])
                        except (ValueError, TimeoutError, ConnectionError):
                            self.ops.alarm("READER_OFFLINE", dict(address=item["address"]))
    async def connection(self, reader, writer):
        self.clients.add(writer)
        send_lock = asyncio.Lock()
        role = None
        owns_gateway = False
        async def send(data):
            async with send_lock:
                writer.write((dumps(data) + "\n").encode())
                await asyncio.wait_for(writer.drain(), 5)
        try:
            hello = loads(await asyncio.wait_for(reader.readline(), 5))
            role = hello.get("role")
            token = os.environ.get("DOOR_" + str(role).upper() + "_TOKEN", "")
            if role not in ("admin", "frontend", "gateway", "platform", "collector") or len(token) < 16 or not isinstance(hello.get("token"), str) or not hmac.compare_digest(hello["token"], token):
                await send(dict(ok=False, error="认证失败"))
                return
            if role == "gateway":
                if self.bus.gateway is not None:
                    await send(dict(ok=False, error="已有网关连接"))
                    role = None
                    return
                self.bus.gateway = send
                owns_gateway = True
            await send(dict(ok=True, role=role))
            while True:
                raw = await reader.readline()
                if not raw:
                    break
                request_id = None
                try:
                    message = loads(raw)
                    request_id = message.get("id")
                    if not isinstance(request_id, str) or not 1 <= len(request_id) <= 64:
                        raise ValueError("请求必须包含长度不超过64的字符串id")
                    response = await self.handle_request(role, request_id, message)
                    await send(response)
                except (ValueError, KeyError, TypeError, AttributeError, PermissionError, TimeoutError, ConnectionError) as error:
                    await send(dict(id=request_id, ok=False, error=str(error)))
        except (ValueError, TypeError, AttributeError, RecursionError, TimeoutError, ConnectionError, asyncio.LimitOverrunError):
            pass
        finally:
            if owns_gateway and self.bus.gateway is send:
                self.bus.disconnect()
                self.power.windows.clear()
                self.power.current.clear()
                self.power.changed.clear()
                self.power.last.clear()
            self.clients.discard(writer)
            writer.close()
            with contextlib.suppress(ConnectionError):
                await writer.wait_closed()
async def serve(args):
    for role in ("ADMIN", "FRONTEND", "GATEWAY", "PLATFORM", "COLLECTOR"):
        if len(os.environ.get("DOOR_" + role + "_TOKEN", "")) < 16:
            raise ValueError("请配置至少16字符的独立端口认证令牌: DOOR_" + role + "_TOKEN")
    tokens = [os.environ["DOOR_" + role + "_TOKEN"] for role in ("ADMIN", "FRONTEND", "GATEWAY", "PLATFORM", "COLLECTOR")]
    if len(set(tokens)) != len(tokens):
        raise ValueError("不同角色必须使用不同认证令牌")
    app = DoorService(args.database)
    async def handler(reader, writer):
        task = asyncio.current_task()
        app.tasks.add(task)
        try:
            if app.connection_limit.locked():
                writer.close()
                await writer.wait_closed()
                return
            async with app.connection_limit:
                await app.connection(reader, writer)
        finally:
            app.tasks.discard(task)
    tls = None
    if args.cert or args.key:
        if not args.cert or not args.key:
            raise ValueError("TLS证书和私钥必须同时指定")
        tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        tls.minimum_version = ssl.TLSVersion.TLSv1_2
        tls.load_cert_chain(args.cert, args.key)
    elif args.host not in ("127.0.0.1", "::1", "localhost"):
        raise ValueError("非本机监听必须配置TLS")
    server = await asyncio.start_server(handler, args.host, args.port, limit=65536, ssl=tls)
    actual_port = server.sockets[0].getsockname()[1]
    if args.ready_file:
        Path(args.ready_file).write_text(str(actual_port), encoding="utf-8")
    print("物防通用门类控制系统监听:", args.host, actual_port, flush=True)
    maintenance = asyncio.create_task(app.maintain())
    def maintenance_done(task):
        if not task.cancelled() and task.exception() is not None:
            print("维护任务异常，停止接收新连接:", str(task.exception()), flush=True)
            server.close()
    maintenance.add_done_callback(maintenance_done)
    try:
        async with server:
            await server.serve_forever()
    finally:
        maintenance.cancel()
        for writer in list(app.clients):
            writer.close()
        for task in list(app.tasks):
            task.cancel()
        await asyncio.gather(maintenance, *list(app.tasks), return_exceptions=True)
        app.store.close()
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--database", default="door_control.sqlite3")
    parser.add_argument("--ready-file")
    parser.add_argument("--cert")
    parser.add_argument("--key")
    options = parser.parse_args()
    try:
        asyncio.run(serve(options))
    except KeyboardInterrupt:
        pass
