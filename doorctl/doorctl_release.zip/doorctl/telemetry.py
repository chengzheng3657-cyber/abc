# 运行事件记录
import time
class EventLog:
    def __init__(self, store, devices):
        self.store = store
        self.devices = devices
        self.alarmed = False
        self.light_until = 0
        self.buttons = {}
        self.open_since = {}
        self.voice = ""
        self.alarm_times = {}
    def record(self, kind, data):
        return self.store.event(kind, data)
    def alarm(self, kind, data):
        self.alarmed = True
        self.voice = "系统故障"
        key = (kind, data.get("door"), data.get("address"))
        now = time.monotonic()
        if now - self.alarm_times.get(key, float("-inf")) >= 60:
            self.record(kind, data)
            self.alarm_times[key] = now
            print("设备告警:", kind, flush=True)
    def passage(self, door):
        self.light_until = time.monotonic() + self.devices.config["light_s"]
        self.record("door_unlocked", dict(door=door))
    def debounce(self, source, key):
        now = time.monotonic()
        pair = (source, key)
        previous = self.buttons.get(pair, float("-inf"))
        if now - previous < 0.2:
            return False
        self.buttons[pair] = now
        return True
    def observe(self, door, state):
        if state["door_closed"]:
            self.open_since.pop(door, None)
        else:
            self.open_since.setdefault(door, time.monotonic())
    def status(self):
        overdue = [door for door, started in self.open_since.items() if time.monotonic() - started >= self.devices.config["door_alarm_s"]]
        voice = "系统故障" if self.alarmed else "请关门" if overdue else self.voice
        return dict(alarm=self.alarmed, light_on=time.monotonic() < self.light_until, voice=voice, overdue_doors=overdue)
