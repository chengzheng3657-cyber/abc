# 端口消息校验
import json
import math
def reject_constant(value):
    raise ValueError("JSON不允许非有限数")
def loads(raw):
    def finite_float(value):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("浮点数超出范围")
        return number
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("JSON字段重复: " + key)
            result[key] = value
        return result
    value = json.loads(raw, parse_constant=reject_constant, parse_float=finite_float, object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise ValueError("消息必须是JSON对象")
    return value
def dumps(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
def integer(value, minimum, maximum, name):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError(name + "超出范围")
    return value
def canonical(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":"))
