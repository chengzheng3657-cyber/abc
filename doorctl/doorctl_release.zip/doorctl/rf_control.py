# 读卡器功率控制
import asyncio
from collections import deque
import time
class ReaderPower:
    def __init__(self, store, devices, bus, events):
        self.store = store
        self.devices = devices
        self.bus = bus
        self.events = events
        self.windows = {}
        self.last = {}
        self.changed = {}
        self.current = {}
        self.lock = asyncio.Lock()
    def configure(self, address, enabled, calibration_ref):
        if type(address) is not int or str(address) not in self.devices.items or self.devices.items[str(address)]["kind"] != "reader":
            raise ValueError("读卡器地址无效")
        if type(enabled) is not bool or not isinstance(calibration_ref, str) or len(calibration_ref) > 256 or (enabled and not calibration_ref.strip()):
            raise ValueError("功率策略需要有效的标定记录引用")
        reader = self.devices.items[str(address)]
        if enabled and not (reader.get("rf") is True and reader.get("power_supported") is True):
            raise ValueError("该设备不支持射频功率配置")
        policy = dict(enabled=enabled, calibration_ref=calibration_ref)
        self.store.put("reader_policy", address, policy)
        self.windows.pop(address, None)
        self.current.pop(address, None)
        self.changed.pop(address, None)
        self.events.record("reader_policy_changed", dict(address=address, **policy))
        return policy
    async def read_level(self, address):
        data = await self.bus.request(address, 0x01, timeout=self.devices.config["query_timeout_s"])
        level = data.get("power")
        config = self.devices.config
        if type(level) is not int or not config["power_min"] <= level <= config["power_max"]:
            raise ValueError("读卡器功率反馈无效")
        return level
    async def sample(self, reader, quality, method):
        address = reader["address"]
        if method != "card" or reader.get("rf") is not True or reader.get("power_supported") is not True:
            return dict(mode="disabled", level=None, confirmed=False)
        async with self.lock:
            config = self.devices.config
            try:
                current = await self.read_level(address)
                previous = self.current.get(address)
                if previous is not None and current != previous:
                    self.windows.pop(address, None)
                    self.changed.pop(address, None)
                self.current[address] = current
                policy = self.store.get("reader_policy", address, {})
                if policy.get("enabled") is not True:
                    return dict(mode="fixed", level=current, confirmed=True)
                samples = self.windows.setdefault(address, deque())
                samples.append(quality["average_us"])
                while len(samples) > config["window"]:
                    samples.popleft()
                average = sum(samples) / len(samples)
                now = time.monotonic()
                step = 1 if average > config["average_high"] else -1 if average < config["average_low"] else 0
                target = max(config["power_min"], min(config["power_max"], current + step))
                ready = len(samples) == config["window"] and now - self.last.get(address, float("-inf")) >= config["power_interval_s"]
                if target != current and ready:
                    await self.bus.request(address, 0x06, {"level": target}, config["query_timeout_s"])
                    actual = await self.read_level(address)
                    self.current[address] = actual
                    if actual != target:
                        self.changed.pop(address, None)
                        raise ValueError("功率配置回读不一致")
                    current = actual
                    self.last[address] = now
                    self.changed[address] = now
                    self.windows[address].clear()
                    self.events.record("power_changed", dict(address=address, level=current))
                return dict(mode="adaptive", level=current, confirmed=True, window_average_us=average, samples=len(samples))
            except (ValueError, TimeoutError, ConnectionError):
                self.current.pop(address, None)
                self.changed.pop(address, None)
                self.windows.pop(address, None)
                raise
    async def persist_stable(self):
        async with self.lock:
            for address, changed in list(self.changed.items()):
                if time.monotonic() - changed < self.devices.config["power_save_s"]:
                    continue
                try:
                    actual = await self.read_level(address)
                except (ValueError, TimeoutError, ConnectionError):
                    continue
                if actual == self.current.get(address):
                    self.store.put("power", address, actual)
                self.changed.pop(address, None)
