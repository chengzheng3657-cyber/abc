# 端口命令行客户端
import argparse
import asyncio
import os
from pathlib import Path
from rpc_client import RpcClient
from validation import loads, dumps
async def main(args):
    request = loads(Path(args.input).read_bytes()) if args.input else {"op": "status"}
    operation = request.pop("op")
    request_id = request.pop("id", None)
    if "request_id" in request or "timeout" in request:
        raise ValueError("消息不能覆盖客户端传输参数")
    client = await RpcClient().connect(args.host, args.port, args.role, os.environ.get("DOOR_" + args.role.upper() + "_TOKEN", ""), cafile=args.ca)
    try:
        result = await client.request(operation, request_id=request_id, **request)
        print(dumps(result), flush=True)
    finally:
        await client.close()
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--role", choices=("frontend", "admin", "platform", "collector"), default="frontend")
    parser.add_argument("--input")
    parser.add_argument("--ca")
    asyncio.run(main(parser.parse_args()))
