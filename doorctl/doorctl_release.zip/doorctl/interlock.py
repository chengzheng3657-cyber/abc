# 通道互锁
import asyncio
class DoorInterlock:
    def __init__(self, store=None):
        self.guard = asyncio.Lock()
        self.store = store
        self.occupied = set(store.get("runtime", "occupied", []) if store else [])
    def reserve(self, doors):
        self.occupied.update(doors)
        self.persist()
    def persist(self):
        if self.store:
            self.store.put("runtime", "occupied", sorted(self.occupied))
    async def check(self, door, query):
        if door not in ("outer", "inner"):
            raise ValueError("门体标识错误")
        try:
            states = {name: await query(name) for name in ("outer", "inner")}
        except (ValueError, TimeoutError, ConnectionError):
            return False, "门锁状态查询失败"
        for name, state in states.items():
            self.release(name, state)
        if self.occupied:
            return False, "通道存在未完成通行"
        other = "inner" if door == "outer" else "outer"
        if not states[other]["door_closed"] or states[other]["bolt"] != "extended":
            return False, "另一门未可靠锁定"
        if not states[door]["door_closed"] or states[door]["bolt"] != "extended":
            return False, "目标门未处于可解锁状态"
        self.reserve([door])
        return True, "互锁检查通过"
    def release(self, door, state):
        if state.get("door_closed") is True and state.get("bolt") == "extended" and door in self.occupied:
            self.occupied.remove(door)
            self.persist()
