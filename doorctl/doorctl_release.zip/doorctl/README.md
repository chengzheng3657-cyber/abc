# Door Control Service
Python 3.11及以上，仅使用标准库。业务输入由采集端和硬件网关通过TCP提交，执行结果、门状态和运维数据通过同一协议返回。生产入口不生成卡号、脉冲、门磁或锁舌状态，也不将软件测试结果记为设备实测结果。
## 目录与命名
生产代码按驱动、协议、业务和存储职责命名：
|文件|职责|
|---|---|
|service.py|连接管理、角色授权、请求处理与周期任务|
|devices.py|地址和门体映射、上线状态、配置校验|
|wiegand_input.py|采集帧边界检查、32位计时回绕处理|
|wiegand_codec.py|Wiegand26校验和标识提取|
|timing.py|帧间隔偏差统计和质量分级|
|access.py|用户门体授权和查询|
|interlock.py|开门请求协调与持久化通行占用|
|locks.py|命令、运动事件和位置回读|
|rs485.py|报文编解码、流解析、事务调度|
|rf_control.py|设备功率回读、窗口统计和受控配置|
|recovery.py|超时后状态核验和保护闭锁|
|telemetry.py|事件、告警、照明及语音输出状态|
|store.py|SQLite持久化、事件队列和请求日志|
|validation.py|严格JSON与字段校验|
|rpc_client.py|端口客户端、请求关联和连接清理|
|cli.py|从采集文件或管理消息发起端口请求|
`tests/`单独保存测试数据生成器、设备替身和自动验证脚本。发布源码包不包含该目录；完整审查包保留这些文件和测试来源。此前版本保留在原目录，未改写历史结果。
## 启动
为ADMIN、FRONTEND、GATEWAY、PLATFORM、COLLECTOR分别设置不同的随机令牌，每个至少16字符。推荐用`python -c "import secrets; print(secrets.token_urlsafe(32))"`为各角色分别生成令牌，不能重复使用。
环境变量名称为DOOR_ADMIN_TOKEN、DOOR_FRONTEND_TOKEN、DOOR_GATEWAY_TOKEN、DOOR_PLATFORM_TOKEN、DOOR_COLLECTOR_TOKEN。
```bash
python service.py --host 127.0.0.1 --port 8765 --database doorctl.sqlite3
```
本机接口默认不启用TLS。监听其他地址必须同时提供`--cert`和`--key`；客户端通过`--ca`指定信任证书，网关客户端可使用`RpcClient.connect(..., cafile=...)`。
没有设备连接时，status返回unknown，不生成开锁成功结果。硬件适配端需要实现下面的网关协议，并提交真实门磁和锁舌反馈；本项目没有随源码附带特定厂家串口驱动或电机固件。
## 消息协议
连接后先发送UTF-8 JSON对象并附换行：
```json
{"role":"frontend","token":"该角色的访问令牌"}
```
认证成功返回`{"ok":true,"role":"frontend"}`。之后每个请求均包含长度1至64的字符串id，以及op。每行不超过65536字节。不接受重复JSON字段、非对象消息、非有限数值或无效字段类型。
正常响应为`{"id":"请求标识","ok":true,"data":...}`，输入或权限错误为`{"id":"请求标识","ok":false,"error":"原因"}`。业务是否成功由data.success和data.result表示，ok=true不意味着门已打开。
角色与接口：
|角色|可用接口|
|---|---|
|frontend|status|
|collector|scan|
|gateway|register、bus_rx；接收bus_tx推送|
|admin|status、grant、configure、reader_policy、button、events|
|platform|events、ack_events|
前端显示组件只持有FRONTEND令牌。实际采集组件持有COLLECTOR令牌，和硬件总线网关建立独立连接。不要在gateway接收循环中同步等待scan结果，否则会阻塞总线应答。不得把COLLECTOR或GATEWAY令牌交给普通界面用户。
## 身份采集
scan由采集端提交以下实际字段：
- capture_id：16至64字符的唯一采集帧标识，建议使用终端采集会话标识加递增帧序号。
- door：outer或inner。
- reader：已注册读卡器的整数地址。
- method：card、fingerprint、face或iris。
- pulses：恰好26条采集记录，每条为`{"line":"D0或D1","tick_us":32位无符号微秒计数}`。
时间戳必须由采集硬件获取，服务不将网络到达时刻当成微秒级GPIO中断时刻。生物识别匹配和长卡号到唯一24位用户标识的映射由终端负责，原始图像或特征值不通过韦根接口传输。
CLI不提供按用户ID生成脉冲的选项。采集组件保存的消息文件可以经端口提交：
```bash
python cli.py --role collector --input /path/to/capture.json
python cli.py --role frontend
python cli.py --role admin --input /path/to/access_update.json
```
文件必须包含op与对应接口的字段，不能用用户标识替代真实的26位采集帧。cli将JSON文件中的内容发送到端口，结果从服务端返回后打印。
重复capture_id一律拒绝。对于scan、button、grant、configure、reader_policy，客户端应为每个逻辑请求保留同一id，网络重试时复用该id。相同id且内容一致返回已经保存的响应，不再次驱动；内容变化时拒绝。处理开始后若进程中断，重试返回结果待核实，需通过status与现场检查确认，不重发动作。请求日志保留至管理员制定归档策略后再处理，不自动删除。
## 设备与总线
register的device字段包含address、kind、door，可包含direction、rf、power_supported。address为1至247整数，kind为lock或reader，door为outer或inner，direction为normal或reverse，能力字段为布尔值。每个门体各维护一个锁具和一个读卡器映射，同地址或同门体同类设备冲突拒绝注册。设备安装参数变更应在停止服务后由受控配置迁移完成，接口不会静默覆盖在线设备身份。
服务向网关推送`{"type":"bus_tx","frame":"十六进制字节"}`。网关将采集到的总线字节通过bus_rx的frame字段回传，可提交分片或多帧。生产接口没有故障注入、时序扰动等测试参数。
帧格式为AA、地址、命令、数据长度、UTF-8 JSON载荷、校验和、55；各固定字段1字节，载荷最多240字节，校验和为地址至载荷各字节之和对256取模。此为本项目的应用协议，真实网关或设备固件必须完成适配。
|命令|用途|反馈|
|---|---|---|
|01|状态查询|81，回传seq、ok:true和设备状态|
|02|解锁|82确认，然后07运动开始、08运动停止|
|03|闭锁|83确认，然后07运动开始、08运动停止|
|06|功率配置|86确认，再查询power回读|
|09|锁具故障事件|携带当前op_id；同时记录设备告警|
查询锁具时，door_closed必须为布尔值，bolt为extended、retracted或moving。查询支持功率配置的读卡器时，power必须为允许范围内的整数。应答必须匹配请求seq、地址和命令；运动事件必须匹配op_id。重复、过期和乱序事件不能推进动作。
事务锁覆盖发送、应答和超时清理，网关仍需对物理RS-485线路实施驱动使能、半双工仲裁和串口错误处理。服务端计时覆盖排队、写出和应答等待，运动超时依据实际收到的开始事件计时，不在命令确认后重新获得完整启动时限。
## 互锁与结果
普通开门前在同一互锁锁内查询两道门，核对目标门可解锁、另一门可靠闭锁，并先落库占用再驱动。通行占用跨进程重启保留，只能由门磁关闭和锁舌伸出这两个真实反馈共同释放。
UNLOCKED只表示锁舌缩回已确认，不能等同于门被人员推开。LOCKED要求门磁关闭且锁舌伸出。查询失败时输出unknown；目标位置不符或故障事件进入恢复流程。状态回读确认超时后的目标已到位时返回RECOVERED_STATE_CONFIRMED，不把原因进一步断言为已证实的单一机械或通信故障。
button支持inner_open、outer_open、double_lock、clear_alarm和受控double_open。普通开门进入互锁，闭锁前核对门磁。double_open默认禁止，需要管理员明确启用allow_double_open，动作及互锁解除会记录；操作失败保留占用。clear_alarm只确认提示，不伪造门状态或释放通行占用。
状态接口中的operations输出light_on、voice、alarm等数据，由前端驱动显示、照明和播报。照明在确认解锁时预先开启，默认60秒；开门未关提醒依据轮询门磁，默认开启30秒提示。没有人员探测器输入时，不声称已检测到人员进入。
## 功率策略
支持射频配置的读卡器始终先回读真实功率。没有射频功能时返回mode=disabled、level=null；设备反馈失败返回错误，不填默认功率。
自适应策略仅由管理员通过reader_policy配置address、enabled和calibration_ref启用。calibration_ref是实际标定记录引用，软件保存该引用但不替代标定工作；网关上报能力不能自行启用该策略。启用后累积完整窗口、限制调节间隔、逐档配置、回读确认，并在稳定周期结束后再次回读再持久化。连接断开后清除会话内样本和功率缓存。
时序偏差只表示韦根传输时序，不能独立证明射频强度。是否将该指标用于特定终端的功率策略，需要实际设备和现场数据验证。
## 数据与验证
用户权限、配置、通行占用、采集去重标识、请求日志及运维事件保存于SQLite。周期状态查询恢复离线检测，重复告警限制为同类同设备每60秒记录一次。平台通过events增量拉取未确认事件并用ack_events确认，断线期间继续存储，下次连接补传。
旧配置中的power_initial和旧设备字段correlation_validated只在启动迁移时移除并记录事件，不再参与功率控制。旧客户端需要按新角色及采集帧契约升级，不提供生成脉冲的兼容入口。
验证命令：
```bash
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/test_network.py --output tests/network_result.json
```
29项单元与缺陷回归测试、15项端口场景验证的实际结果保存在tests目录。端口场景使用该目录内明确标识的设备替身；它验证软件协议与异常处理，不是实际门锁验收报告。生产源码包不带这些工具，须接入实际采集端和网关后才能获得现场通行数据。源码创建时间、测试报告和提交记录不得用于倒推未经证明的既有研发时间。
