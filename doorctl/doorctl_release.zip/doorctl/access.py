# 门禁授权表
class AccessRules:
    def __init__(self, store):
        self.store = store
        self.users = store.all("user")
    def grant(self, user_id, doors):
        if type(user_id) is not int or not 0 <= user_id < 1 << 24 or not isinstance(doors, list) or any(d not in ("outer", "inner") for d in doors):
            raise ValueError("用户或门体授权数据错误")
        value = dict(user_id=user_id, doors=sorted(set(doors)))
        self.store.put("user", user_id, value)
        self.users[str(user_id)] = value
        return value
    def check(self, user_id, door):
        user = self.users.get(str(user_id))
        return user is not None and door in user["doors"]
