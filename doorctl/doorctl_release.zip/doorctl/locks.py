# 门锁驱动
import asyncio
import secrets
import time
class DoorLocks:
    def __init__(self, devices, bus, events=None):
        self.events = events
        self.devices = devices
        self.bus = bus
        self.active = {}
        self.states = {}
        self.device_locks = {}
        bus.event_handler = self.event
    async def query(self, door):
        item = self.devices.find("lock", door, require_online=False)
        data = await self.bus.request(item["address"], 0x01, timeout=self.devices.config["query_timeout_s"])
        if type(data.get("door_closed")) is not bool or data.get("bolt") not in ("extended", "retracted", "moving"):
            raise ValueError("门锁状态无效")
        state = dict(door_closed=data["door_closed"], bolt=data["bolt"], observed_at=time.time())
        self.states[door] = state
        return state
    async def event(self, address, command, data):
        if command == 0x09 and self.events:
            self.events.alarm("DEVICE_FAULT", dict(address=address, op_id=data.get("op_id")))
        action = self.active.get(address)
        if action is None or data.get("op_id") != action["op_id"]:
            return
        if command == 0x07 and action["phase"] == "waiting_start":
            action["phase"] = "moving"
            self.bus.silent.add(address)
        elif command == 0x08 and action["phase"] == "moving":
            action["phase"] = "stopped"
        elif command == 0x09 and action["phase"] in ("waiting_start", "moving"):
            action["phase"] = "fault"
        else:
            return
        action["queue"].put_nowait((command, time.monotonic()))
    async def move(self, door, unlock=True):
        try:
            address = self.devices.find("lock", door, require_online=False)["address"]
        except ValueError as error:
            return dict(success=False, result="DEVICE_UNAVAILABLE", phase="startup", door=door, expected="retracted" if unlock else "extended", reason=str(error))
        guard = self.device_locks.setdefault(address, asyncio.Lock())
        async with guard:
            return await self.execute(address, door, unlock)
    async def execute(self, address, door, unlock):
        action = dict(op_id=secrets.token_hex(6), queue=asyncio.Queue(maxsize=3), phase="waiting_start")
        self.active[address] = action
        expected = "retracted" if unlock else "extended"
        phase = "startup"
        config = self.devices.config
        try:
            sent_at = time.monotonic()
            await self.bus.request(address, 0x02 if unlock else 0x03, {"op_id": action["op_id"]}, config["query_timeout_s"])
            remaining = max(0, config["start_timeout_s"] - (time.monotonic() - sent_at))
            if action["queue"].empty() and remaining == 0:
                raise TimeoutError("启动等待超时")
            command, started_at = await self.next_event(action["queue"], remaining)
            if command != 0x07 or started_at > sent_at + config["start_timeout_s"]:
                raise ValueError("运动启动未确认")
            phase = "motion"
            remaining = max(0, config["motion_timeout_s"] - (time.monotonic() - started_at))
            command, stopped_at = await self.next_event(action["queue"], remaining)
            if command != 0x08:
                raise ValueError("锁具报告运动故障")
            if stopped_at > started_at + config["motion_timeout_s"]:
                raise TimeoutError("锁舌运动超时")
            self.bus.silent.discard(address)
            phase = "verification"
            state = await self.query(door)
            if state["bolt"] != expected or (not unlock and not state["door_closed"]):
                raise ValueError("门锁未到目标状态")
            self.states[door] = dict(state, phase="unlocked" if unlock else "locked")
            return dict(success=True, result="UNLOCKED" if unlock else "LOCKED", door=door, op_id=action["op_id"], state=state)
        except (ValueError, TimeoutError, ConnectionError) as error:
            self.states[door] = dict(phase="unknown")
            return dict(success=False, result="TIMEOUT" if isinstance(error, TimeoutError) else "ACTION_FAILED", phase=phase, door=door, expected=expected, reason=str(error), op_id=action["op_id"])
        except asyncio.CancelledError:
            self.states[door] = dict(phase="unknown")
            raise
        finally:
            self.bus.silent.discard(address)
            self.active.pop(address, None)
    async def next_event(self, queue, remaining):
        if not queue.empty():
            return queue.get_nowait()
        if remaining <= 0:
            raise TimeoutError("动作事件等待超时")
        return await asyncio.wait_for(queue.get(), remaining)
