# 运行数据存储
import json
import sqlite3
import time
class StateStore:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS kv (kind TEXT, key TEXT, value TEXT, PRIMARY KEY(kind,key))")
        self.db.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, at REAL, kind TEXT, data TEXT, delivered INTEGER DEFAULT 0)")
        self.db.commit()
    def put(self, kind, key, value):
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO kv VALUES (?,?,?)", (kind, str(key), json.dumps(value, ensure_ascii=False, allow_nan=False)))
    def get(self, kind, key, default=None):
        row = self.db.execute("SELECT value FROM kv WHERE kind=? AND key=?", (kind, str(key))).fetchone()
        return json.loads(row[0]) if row else default
    def all(self, kind):
        return {k: json.loads(v) for k, v in self.db.execute("SELECT key,value FROM kv WHERE kind=?", (kind,))}
    def event(self, kind, data):
        with self.db:
            cur = self.db.execute("INSERT INTO events(at,kind,data) VALUES(?,?,?)", (time.time(), kind, json.dumps(data, ensure_ascii=False, allow_nan=False)))
        return cur.lastrowid
    def events(self, after=0, pending=False):
        query = "SELECT id,at,kind,data FROM events WHERE id>?" + (" AND delivered=0" if pending else "") + " ORDER BY id LIMIT 200"
        return [dict(id=r[0], at=r[1], kind=r[2], data=json.loads(r[3])) for r in self.db.execute(query, (after,))]
    def ack(self, ids):
        with self.db:
            self.db.executemany("UPDATE events SET delivered=1 WHERE id=?", ((i,) for i in ids))
    def close(self):
        self.db.close()
    def begin_request(self, role, request_id, digest):
        key = role + ":" + request_id
        existing = self.get("request", key)
        if existing:
            if existing["digest"] != digest:
                raise ValueError("请求ID已用于其他内容")
            if existing["status"] != "complete":
                raise ValueError("请求结果尚未确认，请查询设备状态，禁止重复驱动")
            return existing["response"]
        self.put("request", key, dict(digest=digest, status="pending"))
        return None
    def finish_request(self, role, request_id, digest, response):
        self.put("request", role + ":" + request_id, dict(digest=digest, status="complete", response=response))
