# Wiegand26帧校验
class Wiegand26:
    def validate(self, bits):
        if len(bits) != 26 or any(type(b) is not int or b not in (0, 1) for b in bits):
            raise ValueError("韦根帧格式错误")
        if sum(bits[1:13]) % 2 != bits[0] or (1 ^ (sum(bits[13:25]) % 2)) != bits[25]:
            raise ValueError("韦根奇偶校验失败")
        return int("".join(map(str, bits[1:25])), 2)
