# 动作恢复处理
class LockRecovery:
    def __init__(self, locks, events):
        self.locks = locks
        self.events = events
    async def recover(self, result):
        if result.get("success"):
            return result
        door = result["door"]
        try:
            state = await self.locks.query(door)
        except (ValueError, TimeoutError, ConnectionError):
            self.events.alarm("STATE_UNKNOWN", dict(door=door))
            return dict(result, result="STATE_UNKNOWN", state=None)
        target_reached = state["bolt"] == result["expected"] and (result["expected"] == "retracted" or state["door_closed"])
        if result.get("result") == "TIMEOUT" and result.get("phase") in ("motion", "verification") and target_reached:
            self.events.record("action_feedback_timeout", dict(door=door, state=state, op_id=result["op_id"]))
            return dict(result, success=True, result="RECOVERED_STATE_CONFIRMED", state=state)
        self.events.alarm("LOCK_FAULT", dict(door=door, phase=result.get("phase"), state=state))
        if state["door_closed"] and state["bolt"] != "extended":
            try:
                protection = await self.locks.move(door, unlock=False)
                confirmed = await self.locks.query(door)
                result["protection"] = dict(success=protection["success"] and confirmed["door_closed"] and confirmed["bolt"] == "extended", state=confirmed)
            except (ValueError, TimeoutError, ConnectionError):
                result["protection"] = dict(success=False)
        return dict(result, result="LOCK_FAULT", state=state)
